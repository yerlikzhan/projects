class Writer(object):

	def __init__(self):
		self.f = open("test.txt","a") #opens file with name of "test.txt"
		#f.write("and can I get some pickles on that\n")
		#f.close()
	def writeToFile(self, text):
		self.f.write("%s\n"% (text))
		return True

	def closeFile(self):
		self.f.close()
		return True