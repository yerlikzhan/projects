#Author: Sabyruly Yerlikzhan, Heriot-Watt University, Jun 2015
import sys
import time
from naoqi import ALProxy
import configuration
from writer import Writer
from naoqi import ALModule

IP = IP = "nao.local"
PORT = 9559

class Nao(object):   

    def __init__(self):        
        self.write = Writer()
        self.allProxies()       
        #start recording
        #self.startRecording()
        # Set NAO in Stiffness On, enagages motors on NAO
        self.stiffnessOn()
        # starting with face tracking
        self.face_tracker()

    def allProxies(self):
        self.videoRecorderProxy = ALProxy("ALVideoRecorder", IP, PORT)
        self.tts = ALProxy("ALTextToSpeech", IP, PORT)
        self.motionProxy = ALProxy("ALMotion", IP, PORT)
        self.faceTracker = ALProxy("ALFaceTracker", IP, PORT)
        self.redBallTracker = ALProxy("ALRedBallTracker", IP, PORT)
        self.LEDproxy = ALProxy("ALLeds",IP, PORT)

    def startRecording(self):
        self.videoRecorderProxy.setResolution(1)
        self.videoRecorderProxy.setFrameRate(10)
        self.videoRecorderProxy.setVideoFormat("MJPG")
        self.videoRecorderProxy.startRecording("/home/nao/recordings/cameras", "myvideo")
        return True

    def stiffnessOn(self):
        self.motionProxy.stiffnessInterpolation("Body", 1.0, 1.0)        
        configuration.PoseInit(self.motionProxy)
        #self.GreetExpression()
        return True

    def terminate(self):
        self.videoRecorderProxy.stopRecording()
        self.write.closeFile()
        self.stop_face()
        self.stop_ball()
        self.StiffnessOff()
        sys.exit(0)

    def say(self, text):
        #speak out text (TTS)
        self.write.writeToFile(text)
        self.tts.say(text)
        return True

    def face_tracker(self):
        self.stop_ball()
        # start tracker.
        self.faceTracker.startTracker()
        print "ALFaceTracker started"
        self.write.writeToFile("ALFaceTracker started")
        return True

    def ball_tracker(self):
        self.stop_face()
        # start tracker.
        self.redBallTracker.startTracker()
        print "ALRedBallTracker started"
        self.write.writeToFile("ALRedBallTracker started")
        return True

    def stop_ball(self):
        self.redBallTracker.stopTracker()
        return True

    def stop_face(self):
        self.faceTracker.stopTracker()
        return True

    def idleMotion(self, times):
        # times: number of times it loops and looks around following a pattern
        self.stop_face()
        self.stop_ball()
        jointName = ["HeadYaw", "HeadPitch"]        
        targetAngles = [ [0.0, 0.125, 0.25, 0.375, 0.5, -0.5, -0.375, -0.25, -0.125, 0.0], [0.0, 0.1, 0.15, 0.2, 0.25, -0.25, -0.2, -0.15, -0.1, 0.0]]
        targetTimes = [[0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5], [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5]]
        isAbsolute = True        
        for i in range(times):
            self.motionProxy.angleInterpolation(jointName, targetAngles, targetTimes, isAbsolute)
        self.face_tracker()
        return True

    def StiffnessOff(self): 
        self.motionProxy.stiffnessInterpolation("Body", 0.0, 1.0)
        return True    
    
    def GreetExpression(self):
        self.startRecording()
        self.motionProxy.post.openHand('RHand')        
        configuration.GreetHands(self.motionProxy)
        time.sleep(2)
        self.say("Hello")
        time.sleep(1)
        self.say("my name is Nao")
        time.sleep(1)
        self.say("I'm humanoid robot")
        time.sleep(1)
        self.say("what is your name")
        return True

    def lookAt(self, HeadYaw, HeadPitch, speed):
        self.stop_ball()
        self.stop_face()
        # look at position on pitch and yaw on head motors
        # angles are to be mentioned in Radians
        # HeadYaw (Right is - and Left is +)
        # HeadPitch (up is - and down is +)
        pMaxSpeedFraction = speed
        names = "Head"
        targetAngles = [HeadYaw, HeadPitch]
        self.motionProxy.angleInterpolationWithSpeed(names, targetAngles, pMaxSpeedFraction)
        return True

    def Nod(self, times, time, nodtype):
        self.stop_ball()
        self.stop_face()
        # if nodtyps is "HeadYaw", it nods horizontally
        # if nodtyps is "HeadPitch", it nods vertically
        targetAngles = [0.3, -0.3, 0.0]
        # speed of nodding is calculated according to the time deadline
        # times: is how many times it should nod.
        targetTimes = [time/4.0, time/2.0, time*(3.0/4.0)]
        isAbsolute = True        
        for i in range(times):
            self.motionProxy.angleInterpolation(nodtype, targetAngles, targetTimes, isAbsolute)
        self.face_tracker()
        return True