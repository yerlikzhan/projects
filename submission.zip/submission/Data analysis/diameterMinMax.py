class DiameterMinMax(object):

	def Max(self, gazeX, AOIxmin, AOIxmax):
		if gazeX >= AOIxmax:
			return 1
		if gazeX <= AOIxmin:
			return 0
		if gazeX > AOIxmin and gazeX < AOIxmax:
			return 0

	def Min(self, gazeX, AOIxmin, AOIxmax):
		if gazeX >= AOIxmax:
			return 0
		if gazeX <= AOIxmin:
			return 1
		if gazeX > AOIxmin and gazeX < AOIxmax:
			return 0