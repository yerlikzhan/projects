import glob
from diameterMinMax import DiameterMinMax

diameter=DiameterMinMax()

#array of Gaze data files 
fileListGazeData=glob.glob("data/*.csv")
#array of Start End points files 
fileListStartEnd=glob.glob("data/*.txt")
#array of AOI files moving video 
fileListAOI=glob.glob("data/*.log")
#array of AOI files moving video 
fileListSpeech=glob.glob("data/*.dat")

if len(fileListGazeData) == len(fileListStartEnd) == len(fileListAOI):	
	for i in range(len(fileListGazeData)):
		AOI_NAO=[]
		tempList=[]
		PupilData=[]
		SpeechFrames=[]
		NumOfPupilMax=[]
		NumOfPupilMin=[]
		SpeechDiameter=[]
		GazeData_List = []
		PupilDataOverall=[]
		NumOfGazeFrameNAO=[]
		NumOfPupilMaxSpeech=[]
		NumOfPupilMinSpeech=[]
		NumOfPupilMaxOverall=[]
		NumOfPupilMinOverall=[]
		PupilDiameterAndFrame=[]		
		count = 0

		#ELAN file
		StartEND=open(fileListStartEnd[i],"r");
		#AOI file
		AOI=open(fileListAOI[i],"r");
		#GazeData file
		GazeData=open(fileListGazeData[i],"r");
		#SpeechData file
		SpeechData=open(fileListSpeech[i],"r");
		
		for line in SpeechData:
			count = count + 1
			SpeechData_Tmp = line.split(' ')
			if (SpeechData_Tmp[1] != '--undefined--'):
				SpeechFrames.append(count*40)	
			
		for line in StartEND:
			StartEND_Tmp = line.split('\t')
			Start = StartEND_Tmp[2]
			End = StartEND_Tmp[3]
			
			# convert timestemp to frames
			tmp = Start.replace('.', ':')
			tmp = [int(x) for x in tmp.split(':')]
			t=tmp[0]*3600000 + tmp[1]*60000 +tmp[2]*1000 + tmp[3]
			Startframe=t
			
			# convert timestemp to frames
			tmp = End.replace('.', ':')
			tmp = [int(x) for x in tmp.split(':')]
			t=tmp[0]*3600000 + tmp[1]*60000 +tmp[2]*1000 + tmp[3]
			Endframe=t
		
		#put all lines into an array
		for line in AOI:			
			AOI_Tmp = line.split('\t')			
			if len(AOI_Tmp)==10:
				AOI_Tmp[1]='1'
				AOI_NAO.append(map(int,AOI_Tmp))

		aoi_frame_list = [ x[0]*40 for x in AOI_NAO ]

		for line in GazeData:
			GazeData_List.append(line.split(','))
		
		#put all lines into an array
		for i in range(1,len(GazeData_List)):
			GazeData_List[i][6]=(i-1)*20
			if not GazeData_List[i][21] == '' and int(GazeData_List[i][6])%40 == 0:
				tempList.append(GazeData_List[i][6])
				tempList.append(GazeData_List[i][21])
				try:
					PupilDiameterAndFrame.append(map(float,tempList[0:2]))
				except:
					pass
				tempList=[]

		for i in range(len(PupilDiameterAndFrame)):
			PupilDataOverall.append(PupilDiameterAndFrame[i][1])
			if PupilDiameterAndFrame[i][0] in SpeechFrames:
				SpeechDiameter.append(PupilDiameterAndFrame[i])
		DiameterMinOverall=min(PupilDataOverall) + 0.5
		DiameterMaxOverall=max(PupilDataOverall) - 0.5

		print "User: ", GazeData_List[1][1]
		print "Pupil min and max diameter values"
		print "%.2f" % (DiameterMinOverall-0.5), "%.2f" % (DiameterMaxOverall+0.5)
		gaze_frame_list = [ x[0] for x in PupilDiameterAndFrame ]
			
		for i in range(len(PupilDiameterAndFrame)):
			NumOfPupilMaxOverall.append(diameter.Max(PupilDiameterAndFrame[i][1], DiameterMinOverall, DiameterMaxOverall))
			NumOfPupilMinOverall.append(diameter.Min(PupilDiameterAndFrame[i][1], DiameterMinOverall, DiameterMaxOverall))
		diMax=DiameterMaxOverall - 1.5
		diMin=DiameterMinOverall + 0.7
		for i in range(len(SpeechDiameter)):
			NumOfPupilMaxSpeech.append(diameter.Max(SpeechDiameter[i][1], diMin, diMax))
			NumOfPupilMinSpeech.append(diameter.Min(SpeechDiameter[i][1], diMin, diMax))

		for i,frame in enumerate(gaze_frame_list):
			if frame > Startframe and frame < Endframe and frame in aoi_frame_list:
				PupilData.append(PupilDiameterAndFrame[i][1])
		try:
			DiameterMin=min(PupilData) + 0.5
			DiameterMax=max(PupilData) - 0.5
		except ValueError:
			DiameterMin=0
			DiameterMax=0

		for i,frame in enumerate(gaze_frame_list):
			if frame > Startframe and frame < Endframe and frame in aoi_frame_list:
				NumOfPupilMax.append(diameter.Max(PupilDiameterAndFrame[i][1], DiameterMin, DiameterMax))
				NumOfPupilMin.append(diameter.Min(PupilDiameterAndFrame[i][1], DiameterMin, DiameterMax))				
				NumOfGazeFrameNAO.append(PupilDiameterAndFrame[i][0])
				
		PupilMaxPercentage=(float(sum(NumOfPupilMax))/(len(aoi_frame_list)))*100
		PupilMinPercentage=(float(sum(NumOfPupilMin))/(len(aoi_frame_list)))*100
		PupilMaxPercentageOverall=(float(sum(NumOfPupilMaxOverall))/(len(PupilDiameterAndFrame)))*100
		PupilMinPercentageOverall=(float(sum(NumOfPupilMinOverall))/(len(PupilDiameterAndFrame)))*100
		PupilMaxPercentageSpeech=(float(sum(NumOfPupilMaxSpeech))/(len(SpeechFrames)))*100
		PupilMinPercentageSpeech=(float(sum(NumOfPupilMinSpeech))/(len(SpeechFrames)))*100
		
		print "Amount of time when pupil diameter is maximum during gaze at NAO"
		print "%.2f" % PupilMaxPercentage, "%"
		print "Amount of time when pupil diameter is minimum during gaze at NAO"
		print "%.2f" % PupilMinPercentage, "%"
		print "Amount of time when pupil diameter is maximum overall"
		print "%.2f" % PupilMaxPercentageOverall, "%"
		print "Amount of time when pupil diameter is minimum overall"
		print "%.2f" % PupilMinPercentageOverall, "%"
		print "Amount of time when pupil diameter is maximum while story telling"
		print "%.2f" % PupilMaxPercentageSpeech, "%"
		print "Amount of time when pupil diameter is minimum while story telling"
		print "%.2f" % PupilMinPercentageSpeech, "%"