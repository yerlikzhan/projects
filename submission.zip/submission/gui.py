#Author: Sabyruly Yerlikzhan, Heriot-Watt University, Jun 2015
import Tkinter
from Tkinter import *
from final import Nao

class MainFrame(object):

  def __init__(self, master):

    self.master = master
    self.frame = Frame(self.master)
    self.newLabel = Label(self.frame, text='This is the Nao command center')
    self.taskLabel = Label(self.frame, text='Commands')
    self.txtBox = Entry(self.frame)
    self.newLabel.pack(side=TOP)
    self.txtBox.pack(padx=5)
    self.taskLabel.pack()
    self.greeting = Button(self.frame, text="Greeting", command=self.welcome)
    self.task2a = Button(self.frame, text="Face Tracker", command=self.faceTracker)
    self.task2b = Button(self.frame, text="Ball Tracker", command=self.ballTracker)      
    self.task3a = Button(self.frame, text="Look around", command=self.lookAround)
    self.task3b = Button(self.frame, text="Stop face tracker", command=self.stopFace)
    self.task3c = Button(self.frame, text="Stop ball tracker", command=self.stopBall)
    self.task4 = Button(self.frame, text="Say", command=self.spell)
    self.greeting.pack(side=LEFT)
    self.task2a.pack(side=LEFT)
    self.task2b.pack(side=LEFT)
    self.task3a.pack(side=LEFT)
    self.task3b.pack(side=LEFT)
    self.task3c.pack(side=LEFT)
    self.task4.pack(side=LEFT)    
    self.frame.pack()
    self.frame1 = Frame(master)
    self.task3d = Button(self.frame1, text="look left", command=self.lookDownLeft)
    self.down = Button(self.frame1, text="look down", command=self.lookDown)
    self.task3e = Button(self.frame1, text="look right", command=self.lookDownRight)
    self.task3f = Button(self.frame1, text="look center", command=self.lookStraight)
    self.task3g = Button(self.frame1, text="nodding", command=self.nodding)
    self.task3h = Button(self.frame1, text="shaking", command=self.shaking)
    self.sayHello = Button(self.frame1, text="Nice to meet you", command=self.hello)
    self.goodBye = Button(self.frame1, text="bye", command=self.bye)
    self.task3d.pack(side=LEFT)
    self.down.pack(side=LEFT)
    self.task3e.pack(side=LEFT)
    self.task3f.pack(side=LEFT)
    self.task3g.pack(side=LEFT)
    self.task3h.pack(side=LEFT)
    self.sayHello.pack(side=LEFT)
    self.goodBye.pack(side=LEFT)
    self.frame1.pack()
    self.bottomFrame = Frame(self.master)
    self.bottomFrame.pack(side=BOTTOM)
    self.quit = Button(self.bottomFrame, text="Quit", command=self.exitAll)
    self.quit.pack(side=BOTTOM)
    self.robot = Nao()

  def faceTracker(self):
    self.robot.face_tracker()
    return True

  def ballTracker(self):
    self.robot.ball_tracker()
    return True

  def stopFace(self):
    self.robot.stop_face()
    return True

  def stopBall(self):
    self.robot.stop_ball()
    return True

  def lookAround(self):
    self.robot.idleMotion(1)
    return True

  def spell(self):
    text = self.txtBox.get()
    if len(text) > 0:
      print text
      self.robot.say(text)
    else:
      pass
    return True

  def bye(self):
    self.robot.say("bye bye")
    self.robot.say("thank you")
    return True

  def exitAll(self):
    self.robot.terminate()
    self.frame.quit()
    
  def lookStraight(self):
    self.robot.lookAt(0.0, 0.0, 0.1)
    return True

  def lookDownRight(self):
    self.robot.lookAt(-0.3, 0.3, 0.1)
    return True

  def lookDownLeft(self):
    self.robot.lookAt(0.3, 0.3, 0.1)
    return True

  def lookDown(self):
    self.robot.lookAt(0.0, 0.3, 0.1)
    return True

  def nodding(self):
    self.robot.Nod(1,1,"HeadPitch")
    return True

  def shaking(self):
    self.robot.Nod(1,1,"HeadYaw")
    return True

  def hello(self):
    self.robot.say("nice to meet you")
    return True

  def welcome(self):
    self.robot.GreetExpression()
    return True


root = Tk()
start = MainFrame(root)
root.geometry('600x250')
root.title("Sabyruly Yerlikzhan")
#tkinter.mainloop()
root.mainloop()