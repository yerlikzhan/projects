package com.yerlikzhan.android.countriesprovider;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.net.Uri;
import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity
{	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		//Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void addCountry(View view)
	{
		String cntr = ((EditText)findViewById(R.id.country)).getText().toString().trim();
		String cap = ((EditText)findViewById(R.id.capital)).getText().toString().trim();
		String are = ((EditText)findViewById(R.id.area)).getText().toString().trim();
		String pop = ((EditText)findViewById(R.id.population)).getText().toString().trim();
		String lang = ((EditText)findViewById(R.id.language)).getText().toString().trim();
		String cont = ((EditText)findViewById(R.id.continent)).getText().toString().trim();
		if (cntr.length() > 0 && cap.length() > 0 && cont.length() > 0 &&
				pop.trim().length() > 0 && lang.length() > 0 && are.length() > 0)
		{
			// Add a new country record
			ContentValues values = new ContentValues();
			String inf = (cntr + "," + cap + "," + cont);
			String data = (are + "," + pop + "," + lang);
			values.put(CountriesProvider.COUNTRY, (inf));
			values.put(CountriesProvider.INFORMATION, (data));
			@SuppressWarnings("unused")
			Uri uri = getContentResolver().insert(CountriesProvider.CONTENT_URI, values);
			Toast.makeText(getBaseContext(), "The: " + ((EditText)findViewById(R.id.country)).getText().toString().trim()
					+ " inserted!", Toast.LENGTH_LONG).show();
			((EditText)findViewById(R.id.country)).setText("");
			((EditText)findViewById(R.id.capital)).setText("");
			((EditText)findViewById(R.id.area)).setText("");
			((EditText)findViewById(R.id.continent)).setText("");
	    	((EditText)findViewById(R.id.population)).setText("");
	    	((EditText)findViewById(R.id.language)).setText("");
		}
		else
		{
			Toast.makeText(getBaseContext(), "all fields are mandatory", Toast.LENGTH_LONG).show();
		}
	}
	
	public void showAllCountries(View view)
	{
		// Show all the countries with information about it's capital and continent
		String URL = "content://com.yerlikzhan.provider.CountryProv/countries";
	    Uri countrs = Uri.parse(URL);
	    Cursor cursor = getContentResolver().query(countrs, null, null, null, "country");
	    String report = "";
	    report += "Contry        capital        continent\n";
	    if (!cursor.moveToFirst())
	    {
	    	Toast.makeText(this, " No records yet!", Toast.LENGTH_LONG).show();
	    }
	    else
	    {
	    	do
	    	{	
	    		//get data from country table
	    		String informations = cursor.getString(cursor.getColumnIndex(CountriesProvider.COUNTRY));
	    		//divide it into parts
	    		String parts [] = informations.split(",");
	    		//the first part is country
	    		String first = parts[0];
	    		// second part is capital
	    		String second = parts[1];
	    		// third part is continent
	    		String third = parts[2];
	    		//make a report to show to user
	    		report += first;
	    		report += "      " + second;	    		
	    		report += "      " +  third;
	    		//report += " " + c.getString(c.getColumnIndex(CountriesProvider.ID));
	    		report += "\n";
	        }
	    	while (cursor.moveToNext());
	    	Toast.makeText(this, report, Toast.LENGTH_LONG).show();
	    }
	}
	
	public void deleteAll(View view)
	{
		// delete all the records and the table of the database provider
		String URL = "content://com.yerlikzhan.provider.CountryProv/countries";
	    Uri friends = Uri.parse(URL);
		int count = getContentResolver().delete(friends, null, null);
		String countNum = count +" records are deleted!";
		Toast.makeText(getBaseContext(), countNum, Toast.LENGTH_LONG).show();		
	}
	
	public void close(View view)
	{
		finish();
	}
}