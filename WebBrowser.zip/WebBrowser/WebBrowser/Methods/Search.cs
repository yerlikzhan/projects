﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace WebBrowser.Methods
{
    public class Search
    {   
        //create variables for the get method        
        private string tDisp;
        private string data;
        private string rqSt;
        private string txt;
        private string rdr;
        private string rs;
        private int code;
        
        //method will return the HTML code of the requested url address or status code of request
        public string getResp(string urlAd)
        {
            string respAddress = urlAd;
            string http = "http://";

            /* this condition checks if there was entered URL address with "http://" or without it
               and adds the "http://" if it hadn't been written */ 
            if (!respAddress.StartsWith(http))
            {
                respAddress = http + respAddress;
            }               
            
            // the condition for return the http response with its status code if the request was successfull            
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(respAddress);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream rStr = response.GetResponseStream();
                    StreamReader stRdr = new StreamReader(rStr);                    
                    data = stRdr.ReadToEnd();
                    code = (int)response.StatusCode;
                    tDisp = "Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "200 " 
                        + "(" + response.StatusCode.ToString() + ")" + "\n";
                    txt = data;
                    data = tDisp + "\n" + txt;
                    rdr = data;
                    response.Close();
                    stRdr.Close();
                    return rdr;
                }
            }
                
            //exception to return the requests status if the request was unsuccessful  
            catch (WebException ex)
            {
                var exe = ex.Response as HttpWebResponse;
                rqSt = "";
                if (exe == null)
                {
                    rqSt = "Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "Bad_URL";
                    MessageBox.Show("Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "Bad_URL");
                }
                else
                {
                    rqSt = exe.StatusCode.ToString();

                    if (rqSt == "NotFound")
                    {
                        MessageBox.Show("Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "404 Not Found");
                        rqSt = "Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "404 Not Found";
                    }
                    else if (rqSt == "BadRequest")
                    {
                        MessageBox.Show("Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "400 Bad Request");
                        rqSt = "Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "400 Bad Request";
                    }
                    else if (rqSt == "Forbidden")
                    {
                        MessageBox.Show("Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "403 Forbidden");
                        rqSt = "Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "403 Forbidden";
                    }                    
                }
                rs = rqSt;
            }
            
                // this exception for the case when instead of characters were written symbols
            catch (UriFormatException)
            {
                MessageBox.Show("Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "Bad_URL");
                rqSt = "Yerlikzhan Sabyruly, F21SC_Assesed Course Work 1" + "\n" + "Bad_URL";
                rs = rqSt;
            }
            return rs;
        }

        /* Method checks whether the correct web address is written in the favourites list or not
         * this method is simmilar to the GetResp() method, the only difference 
         * is in that this method returns only the status of resonse */ 
        public string checkStatus(string favourUrl)
        {
            string rspAddr = favourUrl;
            string ht = "http://";

            if (!rspAddr.StartsWith(ht))
            {
                rspAddr = ht + rspAddr;
            }

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(rspAddr);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream rStr = response.GetResponseStream();
                    StreamReader stRdr = new StreamReader(rStr);
                    data = stRdr.ReadToEnd();
                    code = (int)response.StatusCode;
                    tDisp = "200 " + "(" + response.StatusCode.ToString() + ")" + "\n";                    
                    response.Close();
                    stRdr.Close();
                    return tDisp;
                }
                 
            }

            catch (WebException ex)
            {
                var exe = ex.Response as HttpWebResponse;
                rs = rqSt;
            }
            
            catch (UriFormatException)
            {
            }
            return "The web address is incorrect";            
        }                
    }
}
