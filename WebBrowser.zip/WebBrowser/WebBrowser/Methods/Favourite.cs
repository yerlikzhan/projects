﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebBrowser.Methods;
using System.IO;
using System.Net;
using System.Windows.Forms;

namespace WebBrowser.Methods
{
    public class Favourite
    {
        List<string> sites;
        int z = 0;
        string fvrt;
        string name;
        string url;

        public string addName(string nameUrl, string favUrl)
        {            
            foreach (string line1 in File.ReadLines(@"sites.txt"))
            {
                z++;
            }
            MessageBox.Show(z.ToString());
            foreach (string line1 in File.ReadLines(@"sites.txt"))
            {
                if (nameUrl == line1.Substring(0, line1.IndexOf('$')))
                {
                    MessageBox.Show("This name already used");
                    fvrt = "";
                    fvrt = line1.Substring(0, line1.IndexOf('$'));
                    break;
                }
            }

            if (nameUrl != fvrt)
            {
                string ads = favUrl + "$" + nameUrl;
                /*File.WriteAllLines(@"sites.txt", ads);
                */
                sites.Add(nameUrl + "$" + favUrl);
                File.WriteAllText(@"sites.txt", string.Empty);
                foreach (string l in sites)
                    File.AppendAllText(@"sites.txt", l + Environment.NewLine);
                //Favourites.Items.Add(nameUrl.Text);
                nameUrl = "";
                favUrl = "";
                name = nameUrl;
                url = favUrl;
            }
            return name;
        }

        public string addUrl(string nameUrl, string favUrl)
        {
            foreach (string line1 in File.ReadLines(@"sites.txt"))
            {
                z++;
            }
            MessageBox.Show(z.ToString());
            foreach (string line1 in File.ReadLines(@"sites.txt"))
            {
                if (nameUrl == line1.Substring(0, line1.IndexOf('$')))
                {
                    MessageBox.Show("This name already used");
                    fvrt = "";
                    fvrt = line1.Substring(0, line1.IndexOf('$'));
                    break;
                }
            }

            if (nameUrl != fvrt)
            {
                string ads = favUrl + "$" + nameUrl;
                /*File.WriteAllLines(@"sites.txt", ads);
                */
                sites.Add(nameUrl + "$" + favUrl);
                File.WriteAllText(@"sites.txt", string.Empty);
                foreach (string l in sites)
                    File.AppendAllText(@"sites.txt", l + Environment.NewLine);
                //Favourites.Items.Add(nameUrl.Text);
                nameUrl = "";
                favUrl = "";
                name = nameUrl;
                url = favUrl;
            }
            return url;
        }
    }
}
