﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Net;
using System.IO;
using WebBrowser.Methods;
using WebBrowser;

namespace WebBrowser
{
    class MultiTab        
    {        
        //arrays of tabs, textboxes and threads in order to implement multi-trhreading
        Search ser = new Search();
        TabPage[] newTb = new TabPage[999];
        RichTextBox[] richTxt = new RichTextBox[999];
        Thread[] mThrdn = new Thread[999];
        int f;

        //this method adds new tabs
        public void newTab(String adrs, TabControl tabControl)
        {            
            richTxt[f] = new RichTextBox();
            //size of the new textbox on thenew tab page
            richTxt[f].Anchor = (AnchorStyles.Bottom | AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top);
            richTxt[f].Size = new Size(tabControl.Width, tabControl.Height);
            newTb[f] = new TabPage();            
            newTb[f].Controls.Add(richTxt[f]);
            newTb[f].Location = new Point(0, 27);
            newTb[f].Name = "tab" + f.ToString();
            newTb[f].Padding = new Padding();
            newTb[f].Size = new Size(42, 18);
            //new tabs title
            if (adrs == "")
            {
                newTb[f].Text = "";
            }
            else
            {
                newTb[f].Text = adrs;
            }
            newTb[f].UseVisualStyleBackColor = true;
            tabControl.TabPages.Add(newTb[f]);
            mThrdn[f] = new Thread(new ThreadStart(() => ser.getResp(adrs)));
            f++;
        }
        //this method deletes tabs, and checks the quantity of the tabs
        public void deleteTab(int tab, TabControl tabControl, ToolStripMenuItem back)
        {            
            tabControl.TabPages.Remove(tabControl.SelectedTab);            
            f--;
            tab = f;
            if (f == 0)
            {
                back.Enabled = false;
            }
        }
    }
}
