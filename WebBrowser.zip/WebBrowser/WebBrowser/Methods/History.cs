﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WebBrowser.Methods
{
    class History
    {
        public string getHistory()
        {
            string hisLst = "";

            foreach (string ln in File.ReadLines(@"visited_sites.txt"))
            {
                hisLst = hisLst + ln + "\r\n";
            }
            return hisLst;
        }
    }
}
