﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Xml;
using WebBrowser.Methods;

namespace WebBrowser.Methods
{
    public class FavoriteMenue
    {
        //  Declare a list of type Favourite
        private static List<Favourite> arrfavorites = new List<Favourite>();
        //insert URL to xml file
        public static void insertURLfavorite(Favourite url)
        {
            if (url != null)
                if (!(findfav(url.Url)))//check url,in order to prevent duplicate url
                {
                    arrfavorites.Add(url);
                    enterToXMLfavorite();// write url to xml file
                }
        }
        //this method check  url exist or not and return boolean type
        public static bool findfav(string url)
        {
            for (int i = 0; i < arrfavorites.Count; i++)
            {
                if (((Favourite)arrfavorites[i]).Url.Equals(url))
                    return true;
            }
            return false;
        }
        //remove name and url from form
        public static void deletenameurl(string nm)
        {
            for (int i = 0; i < arrfavorites.Count; i++)
            {
                if (((Favourite)arrfavorites[i]).Url.Equals(nm))
                {
                    arrfavorites.RemoveAt(i);
                    break;
                }
            }
        }

        public static Favourite[] getFavorite()
        {
            return arrfavorites.Cast<Favourite>().ToArray();
        }
        //Enter  and write favourite lis
        public static void enterToXMLfavorite()
        {
            Favourite[] f = arrfavorites.Cast<Favourite>().ToArray();
            using (XmlWriter Writerxml = XmlWriter.Create("favorite.xml"))
            {
                Writerxml.WriteStartDocument();
                Writerxml.WriteStartElement("favorites");
                foreach (Favourite ff1 in f)
                {
                    Writerxml.WriteStartElement("favorite");
                    Writerxml.WriteElementString("name_favorite", ff1.Name);
                    Writerxml.WriteElementString("url_favorite", ff1.Url);
                    Writerxml.WriteEndElement();
                }
                Writerxml.WriteEndElement();
                Writerxml.WriteEndDocument();
            }
        }
        // read file for favorite
        public static void selectToXMLfavorite()
        {
            XmlDocument selectXmlDcumt = new XmlDocument();
            selectXmlDcumt.Load("favorite.xml");
            XmlNodeList fse = selectXmlDcumt.SelectNodes("//favorite");
            Favourite f1;
            foreach (XmlNode f2 in fse)
            {
                if (f2.ChildNodes.Count > 0)
                {
                    string nam = f2.SelectSingleNode("name_favorite").InnerText;
                    string ur = f2.SelectSingleNode("url_favorite").InnerText;
                    f1 = new Favourite(nam, ur);
                    insertURLfavorite(f1);
                }
            }

        }

        //Remove url from favorite
        public static void removeURLfromFavo(Favourite f)
        {
            XmlDocument removeXmlDocm = new XmlDocument();
            removeXmlDocm.Load("favorite.xml");
            XmlNodeList nodes = removeXmlDocm.SelectNodes("//favorite");
            foreach (XmlElement element in nodes)
            {
                if (element.SelectSingleNode("url_favorite").InnerText.Equals(f.Url))
                {
                    element.RemoveAll();
                }
            }
            removeXmlDocm.Save("favorite.xml");
            deletenameurl(f.Url);
        }
        //Undate name or url from favorite form
        public static void updateURLfromfavorite(Favourite f)
        {
            XmlDocument updateXmlDocum = new XmlDocument();
            updateXmlDocum.Load("favorite.xml");
            XmlNodeList nodes = updateXmlDocum.SelectNodes("//favorite");
            foreach (XmlElement factor in nodes)
            {
                if (factor.SelectSingleNode("url_favorite").InnerText.Equals(f.Url))
                {
                    factor.SelectSingleNode("name_favorite").InnerText = f.Name;
                }
            }
            updateXmlDocum.Save("favorite.xml");
            arrfavorites.Clear();
            selectToXMLfavorite();
        }
    }
}
