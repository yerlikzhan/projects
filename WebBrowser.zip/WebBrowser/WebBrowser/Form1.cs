﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Net;
using System.IO;
using WebBrowser.Methods;

namespace WebBrowser
{
    public partial class Form1 : Form
    {
        Search serc = new Search();
        History hist = new History();
        MultiTab mult = new MultiTab();
        List<string> sites;        
        string[] visWebs = new string[9999];
        string fvrt;
        int vSite;
        int visSit;
        int tabs;
        int z;
        string path = null;
        string path2 = null;
        string path3 = null;
        
        public Form1()
        {
            path = @"visited_sites.txt";
            path2 = @"home.txt";
            path3 = @"sites.txt";
            if (!File.Exists(path))
            {
                File.Create(path);
            }
            if (!File.Exists(path2))
            {
                File.Create(path2);
            }
            if (!File.Exists(path3))
            {
                File.Create(path3);
            }

            InitializeComponent();

            string startHome;
            int qnty;            
            qnty = File.ReadAllLines(@"visited_sites.txt").Length;
            startHome = File.ReadAllText(@"home.txt");
            if (startHome == "")
            {
                address.Text = "";
            }
            else
            {
                address.Text = startHome;
                display.Text = serc.getResp(address.Text);
            }
            sites = new List<string>();
            vSite = 0;
            visSit = 0;
            visWebs[visSit] = address.Text;
            vSite = visSit;
            vSite = 1;
            visSit = 1;
            tabControl1.SelectedTab.Text = address.Text;

            foreach (string ln in File.ReadLines(@"sites.txt")) 
            {
                string fvts;
                fvts = "";
                fvts = ln.Substring(0, ln.IndexOf('+'));
                Favourites.Items.Add(fvts);
            }

            foreach (string ln in File.ReadLines(@"visited_sites.txt"))  
            {
                ViewHistory.Items.Add(ln);
            }          
            
            foreach (string ln in File.ReadLines(@"sites.txt"))
            {
                sites.Add(ln);
            }

            favUrl.Text = address.Text;
            back.Enabled = false;
            forward.Enabled = false;
            removeTabToolStripMenuItem.Enabled = false;
        }
               
        private void goToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            string txt = "";            
            if (address.Text == txt)
            {
                MessageBox.Show("Please enter URL"); 
            }
            else
            {                       
                tabControl1.SelectedTab.Controls[tabs].Text = serc.getResp(address.Text);
                tabControl1.SelectedTab.Text = address.Text;
                File.WriteAllText(@"visited_sites.txt", hist.getHistory() + address.Text + "  " + DateTime.Now);
                address.Items.Add(address.Text + "  " + DateTime.Now);
                visWebs[visSit] = address.Text;                
                visSit++;
                vSite = visSit;                                
                back.Enabled = true;
            }
            ViewHistory.Items.Add(address.Text);
            favUrl.Text = address.Text;
        }

        private void toolStripComboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                goToolStripMenuItem_Click(new object (), new EventArgs ());
            }
        }
        
        private void clearHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            File.WriteAllText(@"visited_sites.txt", string.Empty);
            ViewHistory.Items.Clear();
        }

        private void goHomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string goHome = "";
            if (File.ReadAllText(@"home.txt") == goHome)
            {
                MessageBox.Show("Please add homepage");
            }
            else
            {
                string line = File.ReadAllText(@"home.txt");
                address.Text = line;
                goToolStripMenuItem_Click(new object(), new EventArgs());
            }
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab.Controls[tabs].Text = hist.getHistory();
        }

        private void editHomePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            File.WriteAllText(@"home.txt", address.Text);
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //visSit = visSit - 1;            
            forward.Enabled = true;
            tabControl1.SelectedTab.Controls[tabs].Text = serc.getResp(address.Text);
            tabControl1.SelectedTab.Text = address.Text;
            address.Text = visWebs[visSit];
            visSit--;
            display.Text = serc.getResp(address.Text);
            if (visSit == 0) back.Enabled = false;            
        }

        private void forwardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (visSit != vSite)
            {
                visSit++;
                address.Text = visWebs[visSit];
                display.Text = serc.getResp(address.Text);
            }
            else
            {
                forward.Enabled = false;                
            }

            back.Enabled = true;
        }

        private void toolStripComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string line = (string)ViewHistory.SelectedItem;
            line = line.Substring(0, line.IndexOf(' '));
            address.Text = line;
            goToolStripMenuItem_Click(new object(), new EventArgs());
        }

        private void deleteHomePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            File.WriteAllText(@"home.txt", string.Empty);
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (nameUrl.Text == "")
            {
                MessageBox.Show("Set the name to the favourite web address");
            }

            else if (favUrl.Text == "")
            {
                MessageBox.Show("Enter the favourite web address");
            }
            else
            {
                foreach (string ln1 in File.ReadLines(@"sites.txt"))
                {
                    z++;
                }

                foreach (string ln1 in File.ReadLines(@"sites.txt"))
                {
                    if (nameUrl.Text == ln1.Substring(0, ln1.IndexOf('+')))
                    {
                        MessageBox.Show("This name already used");
                        fvrt = "";
                        fvrt = ln1.Substring(0, ln1.IndexOf('+'));
                        break;
                    }
                }

                if (nameUrl.Text != fvrt)
                {
                    if (serc.checkStatus(favUrl.Text) != "The web address is incorrect")
                    {
                        sites.Add(nameUrl.Text + "+" + favUrl.Text);
                        File.WriteAllText(@"sites.txt", string.Empty);
                        foreach (string l in sites)
                        {
                            File.AppendAllText(@"sites.txt", l + Environment.NewLine);
                        }

                        MessageBox.Show("Web address successfully added to the list");
                        Favourites.Items.Add(nameUrl.Text);
                    }
                    else if (serc.checkStatus(favUrl.Text) == "The web address is incorrect")
                    {
                        MessageBox.Show("The web address is incorrect");
                    }
                }
            }
        }
        
        private void Favourites_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ln = (string)Favourites.SelectedItem;

            foreach (string ln1 in File.ReadLines(@"sites.txt"))
            {

                if (ln == ln1.Substring(0, ln1.IndexOf('+')))
                {                   
                    fvrt = "";
                    fvrt = ln1.Substring(ln1.IndexOf('+'));
                    favUrl.Text = fvrt.Substring(1);
                    nameUrl.Text = ln1.Substring(0, ln1.IndexOf('+'));
                    break;
                }
            }

            address.Text = fvrt.Substring(1);
            goToolStripMenuItem_Click(new object(), new EventArgs());
        }

        private void addTabToolStripMenuItem_Click(object sender, EventArgs e)
        {        
            address.Text = "";
            mult.newTab(address.Text, tabControl1);
            tabControl1.SelectedIndex = tabControl1.TabPages.Count - 1;
            removeTabToolStripMenuItem.Enabled = true;
            address.Focus();            

            foreach (string line1 in File.ReadLines(@"visited_sites.txt")) 
            {
                ViewHistory.Items.Add(line1);
            }
        }

        private void removeTabToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mult.deleteTab(tabs, tabControl1, removeTabToolStripMenuItem);
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (string ln in File.ReadLines(@"sites.txt"))
            {                
                if (nameUrl.Text == ln.Substring(0, ln.IndexOf('+')))
                {
                    foreach (string ln1 in File.ReadLines(@"sites.txt"))
                    {
                        if (nameUrl.Text == ln1.Substring(0, ln1.IndexOf('+')))
                        {
                            sites.Remove(nameUrl.Text + "+" + favUrl.Text);
                            MessageBox.Show("Successfully deleted");
                        }
                    }
                    Favourites.Items.Remove(nameUrl.Text);
                    nameUrl.Text = "";
                    favUrl.Text = "";
                }                
            }
            File.WriteAllText(@"sites.txt", string.Empty);
            foreach (string l in sites)
            {
                File.AppendAllText(@"sites.txt", l + Environment.NewLine);
            }            
        }           

        private void clearFav_Click(object sender, EventArgs e)
        {
            File.WriteAllText(@"sites.txt", string.Empty);
            Favourites.Items.Clear();

            if (Favourites.Text == nameUrl.Text)
            {
                Favourites.Text = "favourites list";
            }
            
            sites.Clear();
        }

        private void favUrl_Click(object sender, EventArgs e)
        {
            favUrl.Text = "";            
        }

        private void nameUrl_Click(object sender, EventArgs e)
        {
            nameUrl.Text = "";
        }
    }
}
