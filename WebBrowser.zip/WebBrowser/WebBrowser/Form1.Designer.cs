﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace WebBrowser
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.goToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.address = new System.Windows.Forms.ToolStripComboBox();
            this.back = new System.Windows.Forms.ToolStripMenuItem();
            this.forward = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goHomeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editHomePageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteHomePageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewHistory = new System.Windows.Forms.ToolStripComboBox();
            this.clearHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookmarksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.clearFav = new System.Windows.Forms.ToolStripMenuItem();
            this.favUrl = new System.Windows.Forms.ToolStripTextBox();
            this.nameUrl = new System.Windows.Forms.ToolStripTextBox();
            this.Favourites = new System.Windows.Forms.ToolStripComboBox();
            this.addTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage0 = new System.Windows.Forms.TabPage();
            this.display = new System.Windows.Forms.RichTextBox();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage0.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goToolStripMenuItem,
            this.address,
            this.back,
            this.forward,
            this.homeToolStripMenuItem,
            this.historyToolStripMenuItem,
            this.ViewHistory,
            this.clearHistoryToolStripMenuItem,
            this.bookmarksToolStripMenuItem,
            this.Favourites,
            this.addTabToolStripMenuItem,
            this.removeTabToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1076, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // goToolStripMenuItem
            // 
            this.goToolStripMenuItem.Name = "goToolStripMenuItem";
            this.goToolStripMenuItem.Size = new System.Drawing.Size(33, 23);
            this.goToolStripMenuItem.Text = "go";
            this.goToolStripMenuItem.Click += new System.EventHandler(this.goToolStripMenuItem_Click);
            // 
            // address
            // 
            this.address.DropDownWidth = 300;
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(150, 23);
            this.address.KeyDown += new System.Windows.Forms.KeyEventHandler(this.toolStripComboBox1_KeyDown);
            // 
            // back
            // 
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(44, 23);
            this.back.Text = "back";
            this.back.Click += new System.EventHandler(this.backToolStripMenuItem_Click);
            // 
            // forward
            // 
            this.forward.Name = "forward";
            this.forward.Size = new System.Drawing.Size(60, 23);
            this.forward.Text = "forward";
            this.forward.Click += new System.EventHandler(this.forwardToolStripMenuItem_Click);
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goHomeToolStripMenuItem,
            this.editHomePageToolStripMenuItem,
            this.deleteHomePageToolStripMenuItem});
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(50, 23);
            this.homeToolStripMenuItem.Text = "home";
            // 
            // goHomeToolStripMenuItem
            // 
            this.goHomeToolStripMenuItem.Name = "goHomeToolStripMenuItem";
            this.goHomeToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.goHomeToolStripMenuItem.Text = "Go Home";
            this.goHomeToolStripMenuItem.Click += new System.EventHandler(this.goHomeToolStripMenuItem_Click);
            // 
            // editHomePageToolStripMenuItem
            // 
            this.editHomePageToolStripMenuItem.Name = "editHomePageToolStripMenuItem";
            this.editHomePageToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.editHomePageToolStripMenuItem.Text = "Set home page";
            this.editHomePageToolStripMenuItem.Click += new System.EventHandler(this.editHomePageToolStripMenuItem_Click);
            // 
            // deleteHomePageToolStripMenuItem
            // 
            this.deleteHomePageToolStripMenuItem.Name = "deleteHomePageToolStripMenuItem";
            this.deleteHomePageToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.deleteHomePageToolStripMenuItem.Text = "Delete home page";
            this.deleteHomePageToolStripMenuItem.Click += new System.EventHandler(this.deleteHomePageToolStripMenuItem_Click);
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(55, 23);
            this.historyToolStripMenuItem.Text = "history";
            this.historyToolStripMenuItem.Click += new System.EventHandler(this.historyToolStripMenuItem_Click);
            // 
            // ViewHistory
            // 
            this.ViewHistory.Name = "ViewHistory";
            this.ViewHistory.Size = new System.Drawing.Size(250, 23);
            this.ViewHistory.Text = "View History";
            this.ViewHistory.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox3_SelectedIndexChanged);
            // 
            // clearHistoryToolStripMenuItem
            // 
            this.clearHistoryToolStripMenuItem.Name = "clearHistoryToolStripMenuItem";
            this.clearHistoryToolStripMenuItem.Size = new System.Drawing.Size(83, 23);
            this.clearHistoryToolStripMenuItem.Text = "clear history";
            this.clearHistoryToolStripMenuItem.Click += new System.EventHandler(this.clearHistoryToolStripMenuItem_Click);
            // 
            // bookmarksToolStripMenuItem
            // 
            this.bookmarksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.toolStripSeparator1,
            this.clearFav,
            this.favUrl,
            this.nameUrl});
            this.bookmarksToolStripMenuItem.Name = "bookmarksToolStripMenuItem";
            this.bookmarksToolStripMenuItem.Size = new System.Drawing.Size(71, 23);
            this.bookmarksToolStripMenuItem.Text = "favourites";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.addToolStripMenuItem.Text = "add";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.deleteToolStripMenuItem.Text = "delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(169, 6);
            // 
            // clearFav
            // 
            this.clearFav.Name = "clearFav";
            this.clearFav.Size = new System.Drawing.Size(172, 22);
            this.clearFav.Text = "clear favourites list";
            this.clearFav.Click += new System.EventHandler(this.clearFav_Click);
            // 
            // favUrl
            // 
            this.favUrl.Name = "favUrl";
            this.favUrl.Size = new System.Drawing.Size(100, 23);
            this.favUrl.Text = "url";
            this.favUrl.Click += new System.EventHandler(this.favUrl_Click);
            // 
            // nameUrl
            // 
            this.nameUrl.Name = "nameUrl";
            this.nameUrl.Size = new System.Drawing.Size(100, 23);
            this.nameUrl.Text = "name";
            this.nameUrl.Click += new System.EventHandler(this.nameUrl_Click);
            // 
            // Favourites
            // 
            this.Favourites.Name = "Favourites";
            this.Favourites.Size = new System.Drawing.Size(121, 23);
            this.Favourites.Text = "favourites list";
            this.Favourites.SelectedIndexChanged += new System.EventHandler(this.Favourites_SelectedIndexChanged);
            // 
            // addTabToolStripMenuItem
            // 
            this.addTabToolStripMenuItem.Name = "addTabToolStripMenuItem";
            this.addTabToolStripMenuItem.Size = new System.Drawing.Size(59, 23);
            this.addTabToolStripMenuItem.Text = "add tab";
            this.addTabToolStripMenuItem.Click += new System.EventHandler(this.addTabToolStripMenuItem_Click);
            // 
            // removeTabToolStripMenuItem
            // 
            this.removeTabToolStripMenuItem.Name = "removeTabToolStripMenuItem";
            this.removeTabToolStripMenuItem.Size = new System.Drawing.Size(79, 23);
            this.removeTabToolStripMenuItem.Text = "remove tab";
            this.removeTabToolStripMenuItem.Click += new System.EventHandler(this.removeTabToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage0);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1076, 390);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage0
            // 
            this.tabPage0.Controls.Add(this.display);
            this.tabPage0.Location = new System.Drawing.Point(4, 22);
            this.tabPage0.Name = "tabPage0";
            this.tabPage0.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage0.Size = new System.Drawing.Size(1068, 364);
            this.tabPage0.TabIndex = 0;
            this.tabPage0.UseVisualStyleBackColor = true;
            // 
            // display
            // 
            this.display.Dock = System.Windows.Forms.DockStyle.Fill;
            this.display.Location = new System.Drawing.Point(3, 3);
            this.display.Name = "display";
            this.display.Size = new System.Drawing.Size(1062, 358);
            this.display.TabIndex = 0;
            this.display.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1076, 417);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Web Browser";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage0.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem goToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox address;
        private System.Windows.Forms.ToolStripMenuItem back;
        private System.Windows.Forms.ToolStripMenuItem forward;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookmarksToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage0;
        private System.Windows.Forms.RichTextBox display;
        private ToolStripMenuItem goHomeToolStripMenuItem;
        private ToolStripMenuItem editHomePageToolStripMenuItem;
        private ToolStripMenuItem deleteHomePageToolStripMenuItem;
        private ToolStripComboBox ViewHistory;
        private ToolStripMenuItem addToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripComboBox Favourites;
        private ToolStripMenuItem addTabToolStripMenuItem;
        private ToolStripMenuItem removeTabToolStripMenuItem;
        private ToolStripTextBox favUrl;
        private ToolStripTextBox nameUrl;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem clearFav;
    }
}

