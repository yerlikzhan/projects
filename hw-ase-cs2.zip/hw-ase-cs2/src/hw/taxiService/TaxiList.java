package hw.taxiService;

import java.util.LinkedList;

public class TaxiList {
	private LinkedList<String> taxis;
	
	public TaxiList(){
		taxis = new LinkedList<String>();
	}
	
	public void add(String taxi){
		taxis.add(taxi);
	}
	
	public String removeHead(){
		return taxis.poll();
	}
	
	public int getSize(){
		return taxis.size();
	}
	
	public String toString(){
		String re = "";
		for(String s: taxis){
			re += s+"\n";
		}
		return re;
	}
	public boolean isEmpty(){
		return taxis.isEmpty();
	}	
}
