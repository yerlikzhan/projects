package hw.taxiService;

public class Group {
	private String destination;
	private int nbOfPassenger;
	
	public Group(String destination, int nbOfPassenger){
		this.destination = destination;
		this.nbOfPassenger = nbOfPassenger; 
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getNbOfPassenger() {
		return nbOfPassenger;
	}

	public void setNbOfPassenger(int nbOfPassenger) {
		this.nbOfPassenger = nbOfPassenger;
	}
	
	public String toString(){
		String re = getDestination() + "\n"
				+ getNbOfPassenger() + " people\n";
		return re;
	}
	
}
