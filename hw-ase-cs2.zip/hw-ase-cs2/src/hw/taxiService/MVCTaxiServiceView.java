package hw.taxiService;

import java.awt.*;
import java.awt.event.*;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * The Class MVCTaxiServiceView.
 */
public class MVCTaxiServiceView extends JFrame implements Observer{
	
	/**
	 * 
	 */	
	private static final long serialVersionUID = 1L;

	/** The taxi service. */
	private TaxiService taxiService;
	
	/** The groups. */
	private GroupList groups;
	
	/** The taxis. */
	private TaxiList taxis;
	
	//GUI components
    /** The open button. */
	private JButton openButton;
	private JButton stopButton;
    
    /** The kiosks. */
    private JTextArea[] kiosks;
    
    private JTextArea remainingsGroups;
    private JTextArea remainingsTaxis;
    private LogFile logFile = LogFile.getInstance();
	/**
	 * Instantiates a new MVC taxi service view.
	 *
	 * @param taxiService the taxi service
	 */
	public MVCTaxiServiceView(TaxiService taxiService){
		//class variables initialization
		this.taxiService = taxiService;
		this.groups = taxiService.getGroups();
		this.taxis = taxiService.getTaxis();
		
		this.taxiService.addObserver(this);
		
		//Set up window title
		setTitle("Taxi Service!");
		setSize(100,600);
		setLocation(10,20);
		
		//Ensure program ends when window closes
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//add button panel, kiosks field, remaining passengers to the content pane
		Container contentPane = getContentPane();
		contentPane.add(createNorthPanel(),BorderLayout.NORTH);
		contentPane.add(createKiosksPanel(),BorderLayout.CENTER);
		contentPane.add(createRemainingPanel(), BorderLayout.SOUTH);
		pack();
	}
	
	/**
	 * Creates the north panel.
	 *
	 * @return the j panel
	 */
	private JPanel createNorthPanel(){
		//North panel contains button to start the service
		openButton = new JButton("Open Taxi Service");
		stopButton = new JButton("Close Taxi Service");
		disableStopButton();
		JPanel northPanel = new JPanel();
		northPanel.add(openButton);
		northPanel.add(stopButton);
		return northPanel;
	}
	
	/**
	 * Creates the kiosks panel.
	 * The first display shows the passenger groups currently being processed at the windows
	 * @return the j panel
	 */
	private JPanel createKiosksPanel(){
		//Calculate the size of the grid - we want pair windows
		int nbOfKiosks = taxiService.getNbOfKiosks();
		int gridSize = nbOfKiosks / 2;
		JPanel kiosksPanel = new JPanel(new GridLayout(gridSize, 2));
		
		//Create a JTextArea per kiosks
		kiosks  = new JTextArea[nbOfKiosks];
		for (int i = 0; i < nbOfKiosks; i++) {
			kiosks[i]= new JTextArea(5,30);
			//monospaced allows nice tabular layout
			kiosks[i].setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
			kiosks[i].setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.LIGHT_GRAY));
			kiosksPanel.add(kiosks[i]);
		}
		
		return kiosksPanel;
	}
	
	/**
	 * Creates the remaining panel.
	 * The second display shows the remaining passenger groups and taxis.
	 * @return the j panel
	 */
	private JPanel createRemainingPanel(){
		JPanel remainPanel = new JPanel(new GridLayout(1,2));
		remainingsGroups = new JTextArea(20,30);
		remainingsTaxis = new JTextArea(20,30);
		remainingsGroups.setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.LIGHT_GRAY));
		remainingsTaxis.setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.LIGHT_GRAY));
		remainPanel.add(remainingsGroups);
		remainPanel.add(remainingsTaxis);
		return remainPanel;
	}

    public void disableProcessButton() {
    	openButton.setEnabled(false);
    }
    public void enableProcessButton() {
    	openButton.setEnabled(true);
    }	
    public void addProcessTaxiServiceListener(ActionListener al) {
    	openButton.addActionListener(al);
    }
    public void disableStopButton() {
    	stopButton.setEnabled(false);
    }
    public void enableStopButton() {
    	stopButton.setEnabled(true);
    }	
    public void addStopTaxiServiceListener(ActionListener al) {
    	stopButton.addActionListener(al);
    }    
	/**
	 * Update. 
	 * OBSERVER pattern - must provide update methods 
	 * synchronized blocks access to sync methods of the same object until finished
	 */
	@Override
	public synchronized void update(Observable o, Object args) {
		if(taxiService.isClosed())
			disableStopButton();
				
		// display 1
		
		
		for (int i = 0; i < taxiService.getNbOfKiosks(); i++) {
			int kioskNumber = i+1;
			kiosks[i].setText("WINDOW " + kioskNumber + "\n" + taxiService.find(i).getReport());
		}
		
		
		// Display 2
		remainingsGroups.setText("PASSENGER GROUPS (" + groups.getSize()+ ")\n\n"
				+ groups.stringList());
		remainingsTaxis.setText("TAXIS (" + taxis.getSize()+ ")\n\n"
				+ taxis.toString());
	}

}
