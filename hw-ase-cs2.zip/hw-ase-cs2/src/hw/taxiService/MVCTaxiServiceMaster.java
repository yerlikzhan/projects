package hw.taxiService;

public class MVCTaxiServiceMaster {
	
	public static void main(String[] args){
		MVCTaxiServiceMaster demo = new MVCTaxiServiceMaster();
	}
	
	public MVCTaxiServiceMaster(){
		TaxiService model = new TaxiService(); //model
		MVCTaxiServiceView view = new MVCTaxiServiceView(model); //view
		MVCTaxiServiceController controller = new MVCTaxiServiceController(model, view);   
		view.setVisible(true);		
	}
}
