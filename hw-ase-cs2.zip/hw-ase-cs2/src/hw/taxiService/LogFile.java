package hw.taxiService;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class LogFile {
	
	private static volatile LogFile innerInstance = null;	
	//private String logFile; 
	private LogFile () {}
	
	
	public static LogFile getInstance(){
		if(innerInstance == null){
			synchronized (LogFile.class){
				if(innerInstance == null){
					innerInstance = new LogFile();
				}
			}
		}
		return innerInstance; 
	}

	public void writeToLogFile(String report){
		 try{
			 File file = new File("LogFile.txt");
			 if (!file.exists()){
			 	file.createNewFile();
			 }
			 FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
		     BufferedWriter bw = new BufferedWriter(fw);
		     bw.write(report + "\n");
		     bw.close();		       
		 }
		 catch(IOException e){
			 e.printStackTrace();
		 }        
	}
}