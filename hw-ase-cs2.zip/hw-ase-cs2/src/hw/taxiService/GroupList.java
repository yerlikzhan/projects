package hw.taxiService;
import java.util.LinkedList;

public class GroupList {
	private LinkedList<Group> groups;
	
	public GroupList(){
		groups = new LinkedList<Group>();
	}
	
	public void add(Group group){
		groups.add(group);
	}
	
	public Group removeHead(){
		return groups.poll();
	}
	
	public int getSize(){
		return groups.size();
	}
	
	public String stringList(){
		String re = "";
		for(Group g: groups){
			re += g.toString()+"\n";
		}
		return re;
	}
	
	public boolean isEmpty(){
		return groups.isEmpty();
	}
}
