package hw.taxiService;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MVCTaxiServiceController {
	private TaxiService model; //model
	private MVCTaxiServiceView view;
	
	public MVCTaxiServiceController(TaxiService m, MVCTaxiServiceView v){
		this.model = m;
		this.view = v;
		view.addProcessTaxiServiceListener(new ProcessTaxiServicesController());
		view.addStopTaxiServiceListener(new StopTaxiServicesController());
	}
	
    class ProcessTaxiServicesController  implements ActionListener
    {
        public void actionPerformed(ActionEvent e) 
        { 
        	view.disableProcessButton();
        	view.enableStopButton();
    		Thread thread = new Thread (model);
    		thread.start();

        }
    }	
    class StopTaxiServicesController  implements ActionListener
    {
        public void actionPerformed(ActionEvent e) 
        { 
        	view.disableStopButton();
        	//view.enableProcessButton();
        	
        	model.setClosed(true);
        }
    }	    
}
