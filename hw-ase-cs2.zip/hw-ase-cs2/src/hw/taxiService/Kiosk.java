package hw.taxiService;

public class Kiosk extends Thread{
	private int waitTime;   // time waiting between bids
	private int idKiosk;
	private TaxiService taxiService;
	private String report = "";
	
	public Kiosk(int id, TaxiService t){
		this.idKiosk = id;
		this.taxiService = t;
		this.waitTime = 3000 + 700*(idKiosk%2);
	}
	public int getIdKiosk() {
		return idKiosk;
	}
	public void setIdKiosk(int idKiosk) {
		this.idKiosk = idKiosk;
	}
	@Override
	public void run() {
		while (!this.taxiService.isClosed()) {
			
			this.report = this.taxiService.bindTaxiToGroup();
			try {
				sleep(waitTime);
			} catch (InterruptedException e) {
				System.out.println("Kiosk Exception "+ e.getStackTrace());
			}
		}
	}
	
	public String getReport(){
		return report;
	}

}
