package hw.taxiService;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Observable;

public class TaxiService extends Observable implements Runnable {
	private GroupList groups = new GroupList();
	private TaxiList taxis = new TaxiList();
	private boolean closed = false;
	private boolean paused = false;
	private Kiosk[] kiosksThreads;
	private LogFile logFile = LogFile.getInstance();
	private int i = 1;
	private int nbOfKiosks = 5;
	
	String inputGroups = "groups_details.txt";
	String inputTaxis = "taxis.txt";
	
	public TaxiService(){
		populateClient(inputGroups);
		populateTaxi(inputTaxis);

		kiosksThreads = new Kiosk[nbOfKiosks];
		for(int i = 0; i<nbOfKiosks; i++){
			kiosksThreads[i] = new Kiosk(i,this); //Runnable parameter or String
		}
	}

	public TaxiService(int nbOfKiosks){
		this.nbOfKiosks = nbOfKiosks;
		populateClient(inputGroups);
		populateTaxi(inputTaxis);
	}
	
	public void populateClient(String input){
		try{
			BufferedReader br = new BufferedReader(new FileReader(input));
			String line;
			@SuppressWarnings("unused")
			int id = 1;
			while ((line = br.readLine()) != null) {
				String[] groupInfo = line.split("\\s*,\\s*");
				String destination = groupInfo[0];
				int nb = Integer.parseInt(groupInfo[1]);
				
				//Creation of a group
				Group g = new Group(destination, nb);
				groups.add(g);
				
				//increment of id
				id++;
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void populateTaxi(String input){
		try{
			BufferedReader br = new BufferedReader(new FileReader(input));
			String line;
			while ((line = br.readLine()) != null) {
				String[] taxiInfo = line.split("\\s*,\\s*");
				String taxiPlate = taxiInfo[0];

				taxis.add(taxiPlate);
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public synchronized String bindTaxiToGroup(){
		String re = "";
		String rep = "";
		if(taxis.isEmpty() || groups.isEmpty()){
			System.out.println("Finishing");
			closed = true;
			re = "closed";
		}
		else{
		String taxi = taxis.removeHead();
		Group g = groups.removeHead();
		
		re += "Destination: " + g.getDestination()+"\n" 
				+"Passengers: " + g.getNbOfPassenger()+"\n" 
				+"Taxi: " + taxi;
		}		
		rep = "W" + i + ":" + "\n" + re;		
		logFile.writeToLogFile(rep);
		if (i < nbOfKiosks){
			i++;			
		}
		else{
			i = 1;
		}
		//update view display
		setChanged();
		notifyObservers();
    	clearChanged();
    	
		return re;
	}

	//getters and setters
	
	public boolean isClosed(){
		return closed;
	}
	
	public void setClosed(boolean b){
		closed = b;
	}
	
	public boolean isPaused() {
		return paused;
	}

	public void setPaused(boolean paused) {
		this.paused = paused;
	}

	public GroupList getGroups() {
		return groups;
	}

	public void setGroups(GroupList groups) {
		this.groups = groups;
	}

	public TaxiList getTaxis() {
		return taxis;
	}

	public void setTaxis(TaxiList taxis) {
		this.taxis = taxis;
	}

	
	
	public int getNbOfKiosks() {
		return nbOfKiosks;
	}

	public void setNbOfKiosks(int nbOfKiosks) {
		this.nbOfKiosks = nbOfKiosks;
	}

	@Override
	public void run() {
		//loop while not finished
		for(int i = 0; i<nbOfKiosks; i++){
			kiosksThreads[i].start();
		}
		try{
			Thread.sleep(1000);
		}catch(Exception e){
			System.out.println("Taxi Service Exception "+ e.getStackTrace());
		}
	}

	public Kiosk find(int id){
		
		for (int i = 0; i< nbOfKiosks; i++) {
			if (kiosksThreads[i].getIdKiosk() == id){
				return kiosksThreads[i];
			}
		}
		return null;
	}
}
