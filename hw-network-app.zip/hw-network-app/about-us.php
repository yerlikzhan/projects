<!DOCTYPE html>
<?php
    session_start();  
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Françoise Tith">
    <title>About us</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    
</head><!--/head-->

<body class="homepage">
    <header id="header">
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo" width = "70"></a>
                </div>
                
                <div class="collapse navbar-collapse navbar-right">
                  <ul class="nav navbar-nav">


                    <?php
                        include_once 'handler.php'; 

                        echo '
                        <li><a href="index.php">Home</a></li>
                        <li class="active"><a href="about-us.php">About Us</a></li>
                        <li><a href="all_events.php">All events</a></li>';
                        if($user) 
                        { 
                            echo'<li><a href="add-event.php">Add an event</a></li>';
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">';
                            echo ($user1);
                            echo'<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="exit.php">Log out</a></li>';
                        }
                        else
                        {
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Login<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="registration.php">Registration</a></li>
                                 <li><a href="log-in.php">Log in</a></li>';
                        }
                    ?>
                                            </ul>
                                        </li>




                                    </ul>

                                </ul>
                            </div>
                        </div><!--/.container-->
                    </nav><!--/nav-->

                </header><!--/header-->

                <section id="about-us">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <h1 style="color:black;">About us</h1>

                                We are 4 student from Heriot-Watt University:
                                <ul>
                                    <li>Yernar Akshabayev</li>
                                    <li>Vitali Mueller</li>
                                    <li>Yerlikzhan Sabyruly</li>
                                    <li>Françoise Tith</li>  
                                </ul>

                                <h2>This website provides opportunity to share your planned trips in order have a lot of participants. This also good way to have a new friends!!!</h2>
                                <a style="float:left;" class="btn btn-primary btn-lg" role="button" href="overview-new.php">OVERVIEW>></a>                 
                            </div>

                        </div>
                    </div>
        <!--<div id="big-banner-authors" style="background-image: url(images/authors.jpg)">
            <div class="container">
            </div>
        </div>-->
        <img src="images/authors.jpg" class="img-responsive authors-photo"/>
    </section><!--/#all-events-->
    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-10">
                    &copy; 2015 <a href="http://www.macs.hw.ac.uk/">MSc students</a>. All Rights Reserved.
                </div>
                <div class="col-sm-1 pull-right">
                    <a href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F~ft2%2Fnet-app%2Fabout-us.php">
                        <img style="border:0;width:88px;height:31px" src="images/w3c.png" alt="valid HTML!"/>
                    </a>
                </div>
                <div class="col-sm-1 pull-right">
                    <p>
                        <a href="https://jigsaw.w3.org/css-validator/validator?profile=css3&amp;uri=http://www2.macs.hw.ac.uk/~ft2/net-app/about-us.php">
                            <img style="border:0;width:88px;height:31px"
                            src="http://jigsaw.w3.org/css-validator/images/vcss"
                            alt="Valid CSS!" />
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>