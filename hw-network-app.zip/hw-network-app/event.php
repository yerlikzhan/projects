<!DOCTYPE html>
<?php
    session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content=""/>
    <meta name="author" content="Françoise Tith"/>
    <title>Event Manager</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <link href="css/main.css" rel="stylesheet"/>
    <link href="css/responsive.css" rel="stylesheet"/>
    <link href="css/event.css" rel="stylesheet"/>
    <link href="css/chatstyle.css" rel="stylesheet"/>
    
    <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/jquery-ui.min.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key="></script>
    <script type="text/javascript" language="javascript" src="js/map.js"></script>
	<script type="text/javascript" language="javascript" src="js/search.js"></script>
    <script type="text/javascript" language="javascript" src="js/get_event.js"></script>
    <script type="text/javascript" language="javascript" src="js/chat.js"></script>
    
<?php
    include("classes/Event.class.php");
    include("classes/Participant.class.php");
    if(isset($_POST['userAction']))
    { 
        switch($_POST['participate'])
        {
            case 'Participate':
                if(!isset($_COOKIE['user_id'])){
                    echo '<div class="alert alert-danger  alert-dismissable" role="alert">Please <a href="log-in.php">login</a> or <a href="registration.php">register</a><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
                }
                else{
                    require "classes/connection.php";
                    $nbOfError = 0;
                    //already participating
                    $req = $db->prepare('SELECT COUNT(*) FROM participants WHERE event_id_fk=? AND user_id_fk=?');
                    $req->execute(array($_GET["id"], $_COOKIE['user_id']));
                    $data = $req->fetch();
                    $nbOfCount = $data['COUNT(*)'];
                    if($nbOfCount>0)
                        $nbOfError=1;
                    //max number reached
                    $req = $db->prepare('SELECT event_max FROM events WHERE event_id=?');
                    $req->execute(array($_GET["id"]));
                    $data = $req->fetch();
                    $max = $data['event_max'];
                    $nbOfPart = Event::getMaxNbFromEvent($_GET["id"]);
                    if($nbOfPart >= $max)
                        $nbOfError=2;

                    //check
                    if($nbOfError == 0)//check if the user is not already participating
                    {
                        $part = new Participant(-1,$_GET["id"], $_COOKIE['user_id'], 1); //level 2 means administrator of the event/level 1 means only normal participant
                        $part->addToDb();
                        echo '<div class="alert alert-success alert-dismissable">Thanks for participate!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
                    }
                    else if($nbOfError == 1){
                        echo'<div class="alert alert-danger  alert-dismissable" role="alert">You are already participating to the event!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
                    }else{
                        echo'<div class="alert alert-danger  alert-dismissable" role="alert">Max number of participants reached!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
                    }
                }
                break;
            case 'Edit':
                //creating session variable to pass those parameters
                $_SESSION = array();
                $_SESSION['event_id'] = $_GET['id'];
                echo $_SESSION['event_id'];
                header ('Location: edit-event.php'); //redirection to all events
                break;
            case 'Do not participate':
                $part = new Participant(-1,$_GET["id"], $_COOKIE['user_id'], 1); //level 2 means administrator of the event/level 1 means only normal participant
                $part->deleteFromDb();
                echo '<div class="alert alert-success alert-dismissable">You\'r not participating to this event anymore!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
                break;                
            case 'Delete':
                Event::deleteFromDb($_GET['id']);
                header ('Location: all_events.php'); //redirection to all events
                echo '<div class="alert alert-success alert-dismissable">You successfully deleted this event!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
                break;
            default:
                echo '<div class="alert alert-danger" role="alert" class="close" data-dismiss="alert" aria-hidden="true">Something went wrong, please contact the administrator.</div>';
                break;         
        }
    }
?>    
</head><!--/head-->    
</head><!--/head-->

<body class="homepage">
    <header id="header">
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo" width = "70"/></a>
                </div>
                
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                     <?php
                        
                        include_once 'handler.php'; 
                        echo '
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about-us.php">About Us</a></li>
                        <li class="active"><a href="all_events.php">All events</a></li>';
                        if($user) 
                        { 
                            echo'<li><a href="add-event.php">Add an event</a></li>';
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">';
                            echo ($user1);
                            echo'<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="exit.php">Log out</a></li>';
                        }
                        else
                        {
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Login<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="registration.php">Registration</a></li>
                                 <li><a href="log-in.php">Log in</a></li>';
                        }
                    ?>
                                        </ul>
                                    </li>
                                                
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
        
    </header><!--/header-->
    <main>
        <section id="cover-image" class="no-margin">
            <div id="big-banner-bg" style="background-color: grey">
            <div id="big-banner" style="background-image: url(images/big-image.jpg);">
                <div class="event-description">
                    <h1 id="event_title">Visit to Pentland Hills</h1>
                </div>
                <form action="event.php?id=<?php echo $_GET['id']; ?>" method="post"  action="" enctype="multipart/form-data" name="form" role="form">
                    <div class="event-button" id="participation_buttons"></div>
                    <input type="hidden" name="userAction" value="insert" />
                </form>
            </div>
            <div>
        </section><!--/#cover-image-->

        <section id="info-description" style="padding-top:1em;">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 center">
                        <div class="row">
                            <div class="col-sm-12">
                                <h2 >Information</h2>
                                <div class="row">
                                    <div class="col-sm-3">
                                        Date:
                                    </div>
                                    <div class="col-sm-3">
                                       <strong id="event_date">01/03/2015</strong>
                                    </div>
                                    <div class="col-sm-3">
                                        Time:
                                    </div>
                                    <div class="col-sm-3">
                                        <strong id="event_time">09:00AM</strong>
                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-sm-5">Number maximum of person:</div>
                                    <div class="col-sm-1"><strong id="event_max_nb">30</strong></div>
                                    <div class="col-sm-3">Type of event:</div>
                                    <div class="col-sm-3"><strong  id="event_type">Nature</strong>
                                    </div>
                                </div>
                                <div class="row descriptionInfo" >
                                    <div class="col-sm-12">      
                                        <strong  id="event_desc">The Pentland Hills Regional Park is a living, working landscape, which offers great opportunities to experience and enjoy the outdoors. Sculpted by glaciers and water, then shaped by people's interactions over thousands of years, the Pentland Hills are a special place for everyone.
                                        </strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <h2 style="margin-top:1em;">Address</h2>
                                <div id="event_address"></div>
                                <div style="height:430px; background-color:white" id="map-canvas"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 center">
                        <div class="row">
                            <div class="col-sm-12">
                                <h2>Members(<span id="event_nb_pers"></span>)</h2>
                                <div class="event-members">
                                <ul  id="event_participants">
                                    <li><a href="#">Yernar Akshabayev</a></li>
                                    <li><a href="#">Vitali Mueller</a></li>
                                    <li><a href="#">Yerlikzhan Sabyruly</a></li>
                                    <li><a href="#">Françoise Tith</a></li>       
                                </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <h2 style="margin-top:1em;">Chat</h2>
                                                                         
<?php
                        
                        include_once 'handler.php'; 

                        if($user) 
                        { 
                            $date1 = date('d/m/Y---H:i:s');
                            $value1 = $user1.'---'.$date1;

                            echo'

                            <div id="wrapper1">
                                <div id="menu1">
                                    <p class="welcome">Welcome, '; echo($user1);  echo '<b></b></p>
                                    
                                    <div style="clear:both"></div>
                                </div>

                                <div id="chatbox1">
                                    <div id="chatlogs">
                                        LOADING CHATLOGS PLEASE WAIT... 
                                    </div>

                                </div>

                                <form name="form1">
                                    <input style="border:none"  type="hidden"  name="uname" readonly value = '; echo($value1);  echo'<br />
                                    <textarea name="msg" style="width:300px; height:20px"></textarea>
                                    <a href="#" onclick="submitChat()" class="button">Send</a>
                                </form>
                           '; 
                        }
                        else 
                        {
                            echo'

                            <div id="wrapper1">
                                <div id="menu1">
                                    <p class="welcome">Please log in!<b></b></p>
                                    
                                    <div style="clear:both"></div>
                                </div>

                                <div id="chatbox2">
                                    <div id="chatlogs">
                                        LOADING CHATLOGS PLEASE WAIT... 
                                    </div>

                                </div>

                               

                           '



                            ; 
                        }

                        ?>
   
                                  </div>                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-10">
                    &copy; 2015 <a href="http://www.macs.hw.ac.uk/">MSc students</a>. All Rights Reserved.
                </div>
                <div class="col-sm-1 pull-right">
                    <a href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F~ft2%2Fnet-app%2Fevent.php">
                        <img style="border:0;width:88px;height:31px" src="images/w3c.png" alt="valid HTML!"/>
                    </a>
                </div>
                <div class="col-sm-1 pull-right">
                <p>
                    <a href="http://jigsaw.w3.org/css-validator/validator?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F%7Eft2%2Fnet-app%2Fevent.php&amp;profile=css3&amp;usermedium=all&amp;warning=1&amp;vextwarning=">
                        <img style="border:0;width:88px;height:31px"
                            src="http://jigsaw.w3.org/css-validator/images/vcss"
                            alt="Valid CSS!" />
                    </a>
                </p>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">get_event(getUrlVars()["id"],getCookie("username"), getCookie('user_id'));

    </script>
</body>
</html>