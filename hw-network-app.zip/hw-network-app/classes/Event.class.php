<?php
class Event{
	private $id;
	private $place;
	private $address;
	private $date;
	private $time;
	private $maxNb;
	private $type;
	private $description;
	private $imgPath;

	public function __construct($id, $place, $address, $date, $time, $maxNb, $type, $description, $imgPath){
		$this->id=$id;
		$this->place=$place;
		$this->address=$address;
		$this->date=$date;
		$this->time=$time;
		$this->maxNb=$maxNb;
		$this->type=$type;
		$this->description=$description;
		$this->imgPath=$imgPath;
	}

	public function getId()
	{
		$this->id;
	}
	public function getPlace()
	{
		$this->place;
	}
	public function getAddress()
	{
		$this->address;
	}	
	public function getEventDate()
	{
		$this->date;
	}
	public function getTime()
	{
		$this->time;
	}
	public function getMaxNb()
	{
		$this->maxNb;
	}	
	public function getEventType()
	{
		$this->type;
	}
	public function getDescription()
	{
		$this->description;
	}
	public function addToDb()
	{	
		require "connection.php";	
		$req = $db->prepare('INSERT INTO events 
		(event_id, 
		event_place, 
		event_address, 
		event_date, 
		event_time,
		event_max,
		event_type,
		event_description,
		event_img_path
		)
		VALUES(\'\', ?, ?, ?, ?, ?, ?, ?, ?)');
		$req->execute(array($this->place,
		$this->address,
		$this->date,
		$this->time, 
		$this->maxNb,
		$this->type,
		$this->description,
		$this->imgPath));

		$req->CloseCursor();
	}
	public function updateToDb()
	{	
		require "connection.php";	
		$req = $db->prepare('UPDATE events SET
		event_place = ?, 
		event_address = ?, 
		event_date = ?, 
		event_time = ?,
		event_max = ?,
		event_type = ?,
		event_description = ?,
		event_img_path = ?
		WHERE event_id = ?');

		$req->execute(array($this->place,
		$this->address,
		$this->date,
		$this->time, 
		$this->maxNb,
		$this->type,
		$this->description,
		$this->imgPath,
		$this->id));

		$req->CloseCursor();
	}	
	public static function getLastEventId()
	{
		require "connection.php";			
		$req = $db->query('SELECT * FROM events ORDER BY event_id DESC LIMIT 1');	
		$last_id = $req->fetch();
		return $last_id['event_id'];
	}

	public static function getEventFromId($id){
		require "connection.php";		
		$req = $db->prepare('SELECT * FROM events WHERE event_id = ?');	
		$req->execute(array($id)); 
		return $req;

	}

	public static function getAllEventsSinceNow(){
		require "connection.php";		
		$req = $db->query('SELECT * FROM events WHERE event_date >= DATE(NOW()) ORDER BY event_date DESC');	
		return $req;

	}

	public static function getLastEvents(){	
		require "connection.php";	
		$req = $db->query('SELECT * FROM events WHERE event_date >= DATE(NOW()) ORDER BY event_date DESC LIMIT 4');	
		return $req;
	}	

	public static function deleteFromDb($id){
		require "connection.php";
		$req = $db->prepare('DELETE events,participants FROM events,participants WHERE events.event_id = ? AND participants.event_id_fk = ?');
		$req->execute(array($id,$id)); 
		$req->CloseCursor();
	}	

	public static function getMaxNbFromEvent($id){
		$req_part = Participant::getAllParticipantsForAnEventId($id);
		$nbOfParticipant= 0 ;
		while ($row = $req_part->fetch())
		{
			$nbOfParticipant++;
		}
		return $nbOfParticipant;
	}	


}

?>