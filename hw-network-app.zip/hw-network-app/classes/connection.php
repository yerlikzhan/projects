<?php
try
{
	$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
	$db = new PDO('mysql:host=localhost;dbname=hw-netapp', 'root', '', $pdo_options);
	$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); //prevent SQL injection
}
catch (PDOException $e)
{
    die('Erreur : ' . $e->getMessage());
}

?>
