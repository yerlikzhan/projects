<?php
try
{
	$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
	$db = new PDO('mysql:host=db570646086.db.1and1.com;dbname=db570646086', 'dbo570646086', 'hw-netapp', $pdo_options);
}
catch (PDOException $e)
{
    die('Erreur : ' . $e->getMessage());
}

?>
