<?php
class Participant{
	private $id;
	private $event_id;
	private $user_id;
	private $participant_level;
	public function __construct($id,$event_id, $user_id, $participant_level){
		$this->id=$id;
		$this->event_id=$event_id;
		$this->user_id=$user_id;
		$this->participant_level=$participant_level;
	}

	public function getId()
	{
		$this->id;
	}
	public function addToDb()
	{	
		require "connection.php";
		//check that the user aren't already participating to the event
		$req = $db->prepare('INSERT INTO participants 
		(participant_id,
			event_id_fk, 
			user_id_fk,
			participant_level
			)
		VALUES(\'\', ?, ?, ?)');
		$req->execute(array($this->event_id,$this->user_id,$this->participant_level));

		$req->CloseCursor();
	}
	public static function getAllParticipantsForAnEventId($event_id)
	{
		require "connection.php";	
		$req = $db->prepare('SELECT username,participant_level 
			FROM participants 
			INNER JOIN events ON participants.event_id_fk = events.event_id 
			INNER JOIN users_profiles ON participants.user_id_fk=users_profiles.id WHERE events.event_id=?');
		$req->execute(array($event_id));
		return $req;
	}
	public function deleteFromDb(){
		require "connection.php";
		$req = $db->prepare('DELETE participants FROM participants WHERE event_id_fk = ? AND user_id_fk = ?');
		$req->execute(array($this->event_id, $this->user_id)); 
		$req->CloseCursor();
	}

	public function updateDb(){
		require "connection.php";
		$req = $db->prepare('UPDATE participants SET participant_level = ? WHERE event_id_fk = ?');
		$req->execute(array($this->participant_level,$this->id));
		$req->CloseCursor();
	}

}

?>