<!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<meta name="description" content="Home page"/>
	<meta name="author" content="Françoise Tith, Yerlikzhan Sabyruly"/>
	<title>Overview</title>
	<!-- core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet"/>
	<link href="css/main.css" rel="stylesheet"/>
	<link href="css/responsive.css" rel="stylesheet"/>
	<link href="css/index.css" rel="stylesheet"/>		
</head>

<body>
	<header id="header">
		<nav class="navbar navbar-inverse">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo" width = "70"/></a>
				</div>
				
				<div class="collapse navbar-collapse navbar-right">
					<ul class="nav navbar-nav">
						<?php
                        include_once 'handler.php'; 

                        echo '
                        <li><a href="index.php">Home</a></li>
                        <li class="active"><a href="about-us.php">About Us</a></li>
                        <li><a href="add-event.php">Add an event</a></li>
                        <li><a href="all_events.php">All events</a></li>';
                        if($user) 
                        { 
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">';
                            echo ($user1);
                            echo'<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="exit.php">Log out</a></li>';
                        }
                        else
                        {
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Login<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="registration.php">Registration</a></li>
                                 <li><a href="log-in.php">Log in</a></li>';
                        }
                    ?>

					</ul>
				</div>
			</div><!--/.container-->
		</nav><!--/nav-->
		
	</header><!--/header-->
	<h1>Overview of the Network Project:</h1>
	<div>
		<p>First part of the project was to create a user interface of the group project. The Group project is about a social media website which focuses on group meetings, specifically about different tour trips like, hiking trips or visiting a museum etc. The Website allows the user to participate in different Meetups which are organized by a member of that Website. The process and functionality of the program is described in following steps:</p>
		<h3>The Project consists of 7 Sup pages:</h3>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="about-us.php">About Us</a></li>
			<li><a href="all_events.php">All events</a></li>
			<li><a href="registration.php">Registration</a></li>
			<li><a href="profile.php">Profile</a></li>
			<li><a href="log-in.php">Log in</a></li>					
			<li><a href="event.php">Event</a></li>
		</ul>
	</div>
	<div>
		<h4>Step1 <a href="index.php">Home</a>:</h4>
		<p>On the Homepage the user will get general information about the current events and recent events. These page gives user a good overview what the service is all about. </p>
	</div>
	<div>
		<h4>Step2 <a href="all_events.php">All Events:</a>:</h4>
		<p>The user is able to see upcoming events and use the google map to find events which are close to his location by using ZIP code. </p>
		<img src="images/map.jpg" width="229" height="220" alt=""/> 
		<p>The image above shows example events for the chosen location. By clicking on the red markers, a description will appear with detailed information about the event.</p>
		<ul>
			<li>Date</li>
			<li>Location</li>
			<li>Duration</li>
			<li>Category of the Event
				<ol>
					<li>Tourism</li>
					<li>Sport</li>
					<li>Party</li>
					<li>Nature</li>
				</ol>
			</li>
		</ul>
		<p>The user has the choice to register, if new to the service or login on the login page to participate on particular event. </p>
		<img src="images/reg.png" width="541" height="397" alt=""/> 
		<p>By signing up, the user is able to communicate to participants of the upcoming event by using chat sevice.</p>
		<img src="images/chat.png" width="440" height="544" alt=""/> </div>
		<div>
			<h4>Step 3<a href="Registration.php"> Creating own event:</a>:</h4>
			<p>Every user can create own Event by going to Add an Event page:</p>
			<img src="images/formular.png" width="605" height="159" alt=""/> 
			<p>In the image above you can see the event manager formula for creating new event.</p>
		</div>
		<div>
			<h4>The whole process can be described in five Steps:</h4>
			<ol>
				<li>Sign Up</li>
				<li>Chose or Create an Event</li>
				<li>Participate and Communicate</li>
				<li>Meet</li>
				<li>Enjoy</li>


			</ol>
			<img src="images/overview.png" width="899" height="1088" alt=""/> 
		</div>
		<div>
			<h5>In our project we used Bootstrap (http://getbootstrap.com/) template. Bootstrap is a free website of collection of tools to create websites and web applications developed by Mark Otto and Jacob Thornton. It contains HTML and CSS-based design templates for typography, forms, buttons, navigation and other interface components, as well as optional JavaScript extensions like JQuery (http://jquery.com/) which was developed by John Resig. jQuery is a cross-platform JavaScript library designed to simplify the client-side scripting of HTML.</h5>
			<h5>CSS files used:</h5>
			<ol>
				<li>responsive.css: <a href="http://bootstrapzero.com">http://bootstrapzero.com</a></li>
				<li>main.css: <a href="http://bootstrapzero.com">http://bootstrapzero.com</a> + modifications by Françoise and Yernar</li>
				<li>bootstrap.min.css: <a href="http://getbootstrap.com">getbootstrap.com</a> + modification by Françoise for validation W3C</li>
			</ol>
			<h5>CSS file responsive.css used to make our to make our pages more responsive</h5>
			<h5>JavaScript used:</h5>
			<ol>
				<li>bootstrap.min.js: <a href="http://getbootstrap.com">getbootstrap.com</a></li>
				<li>jquery.js</li>
				<li>map.js:</li>
				<li>search.js</li>
				<li>photo_upload.js: by Yernar Akshabayev</li>
			</ol>
			<h5>The new HTML5 features used in our pages:</h5>
			<ol>
				<li>Header tag</li>
				<li>Footer tag</li>
				<li>Section tag</li>
				<li>Date form</li>
				<li>Time form</li>
				<li>Option list</li>
				<li>Number</li>
				<li>Datalist tag</li>
			</ol>
			<h5>New CSS3 features</h5>
			<ol>
				<li>background-position: center;</li>
				<li>background-size: cover;</li>
				<li>background-repeat: no-repeat;</li>
			</ol>
			<h5>The contributors</h5>
			<ol>
				<li>index.php: Françoise Tith + Yerlickzhan Sabyruly</li>
				<li>all_events.php:Françoise Tith + Vitali Mueller</li>
				<li>about-us.php:Françoise Tith + Yerlikzhan Sabyruly</li>
				<li>404.php:Françoise Tith</li>
				<li>add-event.php:Françoise Tith</li>
				<li>event.php:Françoise Tith + Vitali Mueller</li>
				<li>main.css: Françoise Tith + Yernar Akshabayev + Yerlikzhan Sabyruly</li>
				<li>reg.css: Yernar Akshabayev</li>
				<li>addevent.css: Françoise Tith</li>
				<li>event.css: Françoise Tith</li>
				<li>index.css: Françoise Tith</li>
				<li>profile.php: Yernar Akshabayev</li>
				<li>registration.php:Yernar Akshabayev</li>
				<li>log-in.php.php: Yernar Akshabayev</li>
				<li>overview-new.php: Yerlikzhan Sabyruly + Vitali Mueller</li>
			</ol>
			<br/>
		</div>
		<footer id="footer" class="midnight-blue">
			<div class="container">
				<div class="row">
					<div class="col-sm-10">
						&copy; 2015 <a href="http://www.macs.hw.ac.uk/">MSc students</a>. All Rights Reserved.
					</div>
					<div class="col-sm-1 pull-right">
						<a href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F~ft2%2Fnet-app%2Foverview-new.php">
							<img style="border:0;width:88px;height:31px" src="images/w3c.png" alt="valid HTML!"/>
						</a>
					</div>
					<div class="col-sm-1 pull-right">
						<p>
							<a href="http://jigsaw.w3.org/css-validator/validator?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F%7Eft2%2Fnet-app%2Foverview-new.php&amp;profile=css3&amp;usermedium=all&amp;warning=1&amp;vextwarning=">
								<img style="border:0;width:88px;height:31px"
								src="http://jigsaw.w3.org/css-validator/images/vcss"
								alt="Valid CSS!" />
							</a>
						</p>
					</div>
				</div>
			</div>
		</footer><!--/#footer-->
		>>>>>>> 8250d28b05966aaee3670f82f9e44ac23a865100

		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>

	</body>
	</html>
