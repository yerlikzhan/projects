<?php
session_start();
include_once 'handler.php'; 


if($user) {
	setcookie('username', '', time()-1, '/');
	setcookie('password', '', time()-1, '/');
	setcookie('email', '', time()-1, '/');
	setcookie('user_id', '', time()-1, '/');

	session_destroy();
	header ('Location: index.php');

} 
?>