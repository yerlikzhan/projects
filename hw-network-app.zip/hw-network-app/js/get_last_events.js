var myTimer;

function ajax_get_json_last_events(){
	var last_events = document.getElementById("last_events");
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "json/last_events_json.php";
    hr.open("POST", url, true); //last parameter set asynchronous boolean
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		    var d = JSON.parse(hr.responseText);

		    last_events.innerHTML = "";

		    for(var o in d){
                last_events.innerHTML += '<div class="col-xs-12 col-sm-4 col-md-3"><div class="recent-event-wrap"><img class="img-responsive recents" src="'+ 
                d[o].event_img_path+'" alt="No event image"/><div class="overlay"><div class="recent-event-inner"><h3><a href="event.php?id='+
                d[o].event_id+'">'+ d[o].event_place +'</a></h3><p>'+ d[o].event_description +'</p></div></div></div></div>';
		    }
	    }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(null); // Actually execute the request
    last_events.innerHTML = "requesting...";
    myTimer = setTimeout('ajax_get_json_last_events()',10000); //10s
}