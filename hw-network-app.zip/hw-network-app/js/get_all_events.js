var myTimer;

function ajax_get_json_events(){
	var table_events = document.getElementById("table_events");
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "json/all_events_json.php";
    hr.open("POST", url, true); //last parameter set asynchronous boolean
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		    var d = JSON.parse(hr.responseText);

		    table_events.innerHTML = "";

		    for(var o in d){		    	
	    		table_events.innerHTML += '<tr data-href="event.php?id='+d[o].event_id+'"><th scope="row">'+d[o].event_id+
	    		'</th><td><a href="event.php?id='+d[o].event_id+'">'+d[o].event_place+'</a></td><td><a href="event.php?id='+d[o].event_id+'">'+
	    		d[o].event_description+'</td><td>'+d[o].event_date+'</td><td>'+d[o].event_time+'</td></tr>';
		    }
	    }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(null); // Actually execute the request
    table_events.innerHTML = "requesting...";
    myTimer = setTimeout('ajax_get_json_events()',10000); //10s
}