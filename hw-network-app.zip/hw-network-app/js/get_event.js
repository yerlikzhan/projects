var myTimer;
var usernameGlobal = "";

function get_event(id,username,user_id){
    usernameGlobal = username;
    var event_img = document.getElementById("big-banner");
	var event_title = document.getElementById("event_title");
    var event_date = document.getElementById("event_date");
    var event_time = document.getElementById("event_time");
    var event_max_nb = document.getElementById("event_max_nb");
    var event_type = document.getElementById("event_type");
    var event_desc = document.getElementById("event_desc");
    var event_address = document.getElementById("event_address");
    var event_participants = document.getElementById("event_participants");
    var event_nb_pers = document.getElementById("event_nb_pers");

    var participation_buttons = document.getElementById("participation_buttons");

    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "json/all_events_json.php";
    hr.open("GET", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/json");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		    //setting up data objects
		    var data = JSON.parse(hr.responseText);
		    var eventid = 'event'+id;
            var obj =  data[eventid];
            if(obj === undefined)
                document.location.replace("404.html"); 
            //setting GUI
            //info
            event_title.innerHTML =  obj.event_place;
            event_date.innerHTML = obj.event_date;
            event_time.innerHTML = obj.event_time;
            event_max_nb.innerHTML = obj.event_max;
            event_type.innerHTML = obj.event_type;
            event_desc.innerHTML = obj.event_description;  
            event_address.innerHTML = obj.event_address; 
            event_img.style.background = "url('"+obj.event_img_path+"') no-repeat center" ;
            event_img.style.backgroundSize = "cover";

            //participants
            var i= 0;
            for(var participant in obj.event_participants){
                /*if(obj.event_participants[participant] < 2 && obj.event_participants[username] == 2){//if the participant are not admin, display option to set admin of the event and if user is admin
                    event_participants.innerHTML += "<li>" + participant + "(<a href='#'>Set as admin of event!</a>)</li>";
                }
                else{*/
                    if(obj.event_participants[participant] == 2)
                        event_participants.innerHTML += "<li>" + participant + "(Administrator of event)</li>" ;
                    else
                        event_participants.innerHTML += "<li>" + participant + "</li>" ;
                //}
                i++;
            }
            event_nb_pers.innerHTML = i;

            //buttons 
            var found = false;
            for(var participant in obj.event_participants){
                if(username == participant) 
                    found = true; 
            }
            if(found) //if participate, show do not participate button
            {   participation_buttons.innerHTML = '<input type="submit" class="btn btn-warning btn-lg" role="button" name="participate" value="Do not participate"/>';
                if(obj.event_participants[username] == 2){ //if admin can also delete the event
                    participation_buttons.innerHTML = '<input type="submit" class="btn btn-info btn-lg" role="button" name="participate" value="Edit"/>';
                    participation_buttons.innerHTML += '<input type="submit" class="btn btn-danger btn-lg" role="button" name="participate" value="Delete"/>';
                }
            }
            else
                //participation_buttons.innerHTML = '<a class="btn btn-success btn-lg" role="button" href="#">Participate</a>';
            participation_buttons.innerHTML = '<input type="submit" class="btn btn-success btn-lgbtn-lg" role="button" name="participate" value="Participate"/>';
            
	    }
        //else if(hr.status != 200)
            
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(null); // Actually execute the request
/*    event_title.innerHTML = "requesting...";
    event_date.innerHTML = "requesting...";
    event_time.innerHTML = "requesting...";
    event_max_nb.innerHTML = "requesting...";
    event_type.innerHTML = "requesting...";
    event_desc.innerHTML = "requesting...";
    event_address.innerHTML = "requesting...";*/
    event_participants.innerHTML = "";
    myTimer = setTimeout('get_event('+id+',"'+usernameGlobal+'",'+user_id+')',10000); //10s

}
    //
function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
}

function getCookie(sName) {
    var oRegex = new RegExp("(?:; )?" + sName + "=([^;]*);?");

    if (oRegex.test(document.cookie)) {
            return decodeURIComponent(RegExp["$1"]);
    } else {
            return null;
    }
}