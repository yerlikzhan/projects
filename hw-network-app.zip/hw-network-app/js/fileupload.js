(function(){
var dropzoneHtml = document.getElementById('dropzone');
var hiddenImgPath = document.getElementById('imgPath');
var upload = function(files){
  var formData = new FormData(),
      xhr = new XMLHttpRequest(),
      x;
  if(files[0].type == "image/jpeg" || files[0].type == "image/png" ||files[0].type == "image/gif"){
    if(files[0].size<10000000) //10Mo
      formData.append('file[]', files[0]);
    else
      alert("File too voluminous(<10Mo).");
  }
    
  else
    alert("Not authorized type. Please upload a gif, jpg, jpeg or png.");
  //after loaded the image
  xhr.onload = function(){
    var data = JSON.parse(this.responseText);
    if(data[0] !== undefined){
      dropzoneHtml.innerHTML = '<img src="'+data[0].file+'" alt="'+data[0].name+'" class="img_droped"/>'; //display image in dropzone
      hiddenImgPath.value=data[0].file; //changing hidden input to be added in db
    }
  }

  //load the image
  xhr.open('post', 'upload.php');  
  xhr.send(formData);
}
dropzoneHtml.ondrop = function(e){
      e.preventDefault(); //prevent default behaviour (opening the file in the browser)
      this.className = 'dropzone'; //gui
      //console.log(e);
      upload(e.dataTransfer.files);
    };
    //gui
    dropzoneHtml.ondragover = function(){
      this.className = 'dropzone dragover';
      return false;
    };
    dropzoneHtml.ondragleave = function(){
      this.className = 'dropzone';
      return false;
    };       
  }());