function submitChat(){

    form1.uname.readOnly = true;
    form1.uname.style.border = 'none';
    $('#imageload').show();
    var uname = form1.uname.value;
    var msg = form1.msg.value;
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function(){
        if(xmlhttp.readyState==4&&xmlhttp.status==200){
            document.getElementById('chatlogs').innerHTML = xmlhttp.responseText;
            $('#imageload').hide();
        }
    }
    xmlhttp.open('GET','insert.php?uname='+uname+'&msg='+msg,true);
    xmlhttp.send();
}

$(document).ready(function(e) {
    $.ajaxSetup({cache:false});
    setInterval(function() {$('#chatlogs').load('logs.php');}, 2000);
});
