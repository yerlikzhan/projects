-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2015 at 09:57 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hw-netapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
`event_id` int(11) NOT NULL,
  `event_place` varchar(50) NOT NULL,
  `event_address` varchar(50) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `event_max` int(11) NOT NULL,
  `event_type` varchar(30) NOT NULL,
  `event_description` varchar(255) NOT NULL,
  `event_img_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_place`, `event_address`, `event_date`, `event_time`, `event_max`, `event_type`, `event_description`, `event_img_path`) VALUES
(1, 'North Bridge', 'North Bridge, edinburgh, City Center', '2015-04-30', '10:00:00', 5, 'Tourism', 'Let''s go to North Bridge in Edinburgh City Center', ''),
(5, 'Loch Ness', '87 High Street, Royal Mile, Edinburgh, EH1 1SG.', '2015-03-31', '12:00:00', 3, 'Nature', 'Loch Ness is a large, deep, freshwater loch in the Scottish Highlands extending for approximately 23 miles (37 km) southwest of Inverness', 'images/event-covers/lochness.jpg'),
(6, 'Edinaaaa', 'asdasdsad', '2015-05-24', '12:22:00', 2, 'Nature', 'asdasdasd', 'images/event-covers/email1.png');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
`id` int(11) NOT NULL,
  `username` varchar(256) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `username`, `msg`) VALUES
(1, 'ernarch', 'hi maaan'),
(2, 'ernarch', 'hi maaan'),
(3, 'ernarch', 'asd'),
(4, 'ernarch', 'fucking done!'),
(5, 'ernarch', 'llllllllllllllllll'),
(6, 'ernarch', 'IT IS NOT A DICK!!!!!'),
(7, 'ernarch', 'waedww'),
(8, '0<br', 'asd'),
(9, '0<br', 'asdddd'),
(10, '0<br', 'asd'),
(11, '0<br', 'asd'),
(12, 'Monday', 'qwe'),
(13, 'Monday', 'asd'),
(14, 'Monday', 'asdwww'),
(15, 'Mon,', 'qwe'),
(16, 'Mon,', 'qweww'),
(17, 'Mon,', 'qwewwqq'),
(18, 'ernarch<br', 'asd'),
(19, '0<br', 'asd'),
(20, '0<br', 'wwwww'),
(21, '0<br', 'asd'),
(22, 'ernarch,', 'asd'),
(23, 'ernarch,', 'asdwww'),
(24, 'ernarch', 'wwww'),
(25, 'Mon,', 'www'),
(26, 'ernarchMon,', 'asd'),
(27, 'ernarch', 'asd'),
(28, 'ernarch', 'asdqqq'),
(29, 'ernarch2015-03-30', 'qqq'),
(30, 'ernarch---2015-03-30', 'asd'),
(31, 'ernarch---2015-03-30', 'qwww'),
(32, 'ernarch---2015-03-30', 'qwww'),
(33, 'ernarch---2015-03-30', 'qwww'),
(34, 'ernarch---2015-03-3015:48:57<br', 'wwww'),
(35, 'ernarch---2015-03-30---15:49:22<br', 'Hey how are you doing?'),
(36, 'ernarch---30-03-2015---15:50:11<br', 'qweqweqwe'),
(37, 'ernarch---30/03/2015---15:50:42<br', 'ffff'),
(38, 'ernarch', 'asd'),
(39, 'ernarch', 'asdqww'),
(40, 'ernarch---30/03/2015---15:54:15<br', 'ggg'),
(41, 'ernarch---30/03/2015---15:54:15<br', 'hi maaan'),
(42, 'ernarch---30/03/2015---15:58:50<br', 'ggg'),
(43, 'ernarch---30/03/2015---15:58:50<br', 'Hi are you ok?'),
(44, 'ernarch---30/03/2015---16:16:07<br', 'vava');

-- --------------------------------------------------------

--
-- Table structure for table `participants`
--

CREATE TABLE IF NOT EXISTS `participants` (
`participant_id` int(11) NOT NULL,
  `event_id_fk` int(11) NOT NULL,
  `user_id_fk` int(11) NOT NULL,
  `participant_level` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `participants`
--

INSERT INTO `participants` (`participant_id`, `event_id_fk`, `user_id_fk`, `participant_level`) VALUES
(1, 1, 1, 2),
(11, 1, 2, 1),
(13, 5, 1, 2),
(22, 5, 2, 1),
(27, 7, 4, 2),
(29, 1, 5, 1),
(31, 5, 5, 1),
(34, 1, 4, 1),
(45, 5, 4, 1),
(46, 6, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users_profiles`
--

CREATE TABLE IF NOT EXISTS `users_profiles` (
`id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_profiles`
--

INSERT INTO `users_profiles` (`id`, `username`, `password`, `email`) VALUES
(4, 'ernarch', '0dcdfac6c10dc519b90a3df35878ce49', 'ernar.q@mail.ru'),
(5, 'ernarcha', '0dcdfac6c10dc519b90a3df35878ce49', 'qq@mail.ru'),
(6, 'ernarnis', '0dcdfac6c10dc519b90a3df35878ce49', 'erff@mail.ru'),
(7, 'ernarqqq', '0dcdfac6c10dc519b90a3df35878ce49', 'ernjj@mail.ru');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
 ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `participants`
--
ALTER TABLE `participants`
 ADD PRIMARY KEY (`participant_id`);

--
-- Indexes for table `users_profiles`
--
ALTER TABLE `users_profiles`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `participants`
--
ALTER TABLE `participants`
MODIFY `participant_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `users_profiles`
--
ALTER TABLE `users_profiles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
