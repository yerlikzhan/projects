<?php
header("Content-Type: application/json"); 
include("../classes/Event.class.php");		

$events = Event::getLastEvents();

$jsonData = '{';


while ($event = $events->fetch())
{
	$id = $event["event_id"];
	$place = $event["event_place"];
	$description = $event["event_description"];
	$imgPath = $event["event_img_path"];

	$jsonData .= '"event'.$id.
		'":{"event_id":"'.$id.
		'", "event_place":"'.$place.
		'", "event_description":"'.$description.
		'", "event_img_path":"'.$imgPath.
		'"},';
}

$jsonData = chop($jsonData,",");
$jsonData .= '}';
echo $jsonData;
?>