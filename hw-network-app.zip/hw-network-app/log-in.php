    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="Home page"/>
      <meta name="author" content="Yernar Akshabayev"/>
      <title>Login</title>

      <!-- core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet"/>
      <link href="css/main.css" rel="stylesheet"/>
      <link href="css/reg.css" rel="stylesheet"/>
      <link href="css/responsive.css" rel="stylesheet"/>
      <link href="css/index.css" rel="stylesheet"/>
    </head><!--/head-->
    <body>

      <header id="header">
        <nav class="navbar navbar-inverse">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo" width = "70"/></a>
            </div>

            <div class="collapse navbar-collapse navbar-right">
              <ul class="nav navbar-nav">


                <?php
                        include_once 'handler.php'; 

                        echo '
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="all_events.php">All events</a></li>';
                        if($user) 
                        { 
                          echo'<li><a href="add-event.php">Add an event</a></li>';
                          echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">';
                          echo ($user1);
                          echo'<i class="fa fa-angle-down"></i></a>
                          <ul class="dropdown-menu">
                          <li><a href="exit.php">Log out</a></li>';
                         }
                         else
                         {
                          echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Login<i class="fa fa-angle-down"></i></a>
                          <ul class="dropdown-menu">
                           <li><a href="registration.php">Registration</a></li>
                           <li><a href="log-in.php">Log in</a></li>';
                         }
                         ?>
                       </ul>
                     </li>




                   </ul>
                 </div>
               </div><!--/.container-->
             </nav><!--/nav-->

           </header><!--/header-->

           <section id="login_section" class="container text-center">
            <h1>Login page</h1>

            <?php
    include_once 'handler.php'; 

  
    if($user) {
      header ('Location: index.php');
      exit();
    }

    if(!empty($_POST['login']) AND !empty($_POST['password']))
    {

   
     //$login = mysql_real_escape_string(htmlspecialchars($_POST['login']));
     //$password = mysql_real_escape_string(htmlspecialchars($_POST['password']));
     $login=$_POST['login'];
     $password =$_POST['password'];
     
     $nbOfError = 0;
       //$search_user = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_profiles` WHERE `username` = '".$login."' AND `password` = '".$password."'"), 0);
     $passwordmd5 = md5($password);

     $req = $db->prepare('SELECT COUNT(*) FROM users_profiles WHERE username=? AND password=?');
     $req->execute(array($login, $passwordmd5));

     $data = $req->fetch();
     $nbOfError = $data['COUNT(*)'];

     
     //$reqcount = $req[0];

     if($nbOfError == 0)
     {
      
      echo 'Error. Please enter either login or password correctly! or '; echo '<a href=registration.php>Register</a>'; 
    }
    else
    {
       
            $time = 60*60*24; 
            setcookie('username', $login, time()+$time, '/');

            $req = $db->prepare('SELECT id FROM users_profiles WHERE username=?');
            $req->execute(array($login));
            $user_id = $req->fetch()['id'];
            setcookie('user_id', $user_id, time()+$time, '/');

            header ('Location: index.php');
             
          }
        }
        echo '
        <form action="log-in.php" method="post" autocomplete="on" >
          <table class = "reg_table">

            <tr>
              <td class ="reg_td"><label>LOGIN <br></label></td>
              <td><input pattern=".{6,10}" class ="colortext" name="login" type="text" placeholder="Login" title="More than 6 letters required" required></td>
            </tr>



            <tr>
              <td class ="reg_td"><label >PASSWORD <br></label></td>
              <td><input name="password" type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="********" class = "colortext" onchange="form.cpw.pattern = this.value;" required></td>
            </tr>  

          </table>
          <p>
            <input type="submit" name="submit" value="LOGIN" class="btn btn-primary">
          </p>
         
        </form>'?>
      </section>

      <footer id="footer" class="midnight-blue">
        <div class="container">
          <div class="row">
            <div class="col-sm-10">
              &copy; 2015 <a href="http://www.macs.hw.ac.uk/">MSc students</a>. All Rights Reserved.
            </div>
            <div class="col-sm-1 pull-right">
              <a href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F~ft2%2Fnet-app%2FLog-in.php">
                <img style="border:0;width:88px;height:31px" src="images/w3c.png" alt="valid HTML!"/>
              </a>
            </div>
            <div class="col-sm-1 pull-right">
              <p>
                <a href="http://jigsaw.w3.org/css-validator/validator?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F%7Eft2%2Fnet-app%2FLog-in.php&amp;profile=css3&amp;usermedium=all&amp;warning=1&amp;vextwarning=">
                  <img style="border:0;width:88px;height:31px"
                  src="http://jigsaw.w3.org/css-validator/images/vcss"
                  alt="Valid CSS!" />
                </a>
              </p>
            </div>
          </div>
        </div>
      </footer><!--/#footer-->

      <script src="js/jquery.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/photo_upload.js"></script>
    </body>
    </html>
