<!DOCTYPE html>
<?php
    session_start();
    include_once 'handler.php'; 
    if(!$user)
        header ('Location: index.php');  
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Add an event page">
    <meta name="author" content="Françoise Tith">
    <title>Edit an event</title>
    
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/addevent.css" rel="stylesheet">

    <script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/jquery-ui.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key="></script>
    <script language="javascript" type="text/javascript" src="js/map.js"></script>
    <script language="javascript" type="text/javascript" src="js/search.js"></script>
    <script type="text/javascript">
    function displayImg(path, filename){
        dropzoneHtml.innerHTML = '<img src="'+path+'" alt="'+filename+'" class="img_droped"/>'; //display image in dropzone
    }
</script>
<?php
    include("classes/Event.class.php");
    include("classes/Participant.class.php");
    if(isset($_POST['userAction']))
    { 
            
        $event = new Event($_SESSION['event_id'],$_POST['place'],
            $_POST['address'],$_POST['event_date'],
            $_POST['event_time'],$_POST['maxpers'],
            $_POST['event_type'],$_POST['description'],$_POST['imgPath']
            );
        $event->updateToDb();
        echo '<div class="alert alert-success alert-dismissable">Editing successful! Go back to <a href="all_events.php">all events</a>?<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
    }
?>    
</head><!--/head-->

<body class="homepage">


    <header id="header">
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo" width = "70"></a>
                </div>
                
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        
                        
                     <?php
                        include_once 'handler.php'; 

                        echo '
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="all_events.php">All events</a></li>';
                        if($user) 
                        { 
                            echo'<li><a href="add-event.php">Add an event</a></li>';
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">';
                            echo ($user1);
                            echo'<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="exit.php">Log out</a></li>';
                        }
                        else
                        {
                            echo'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Login<i class="fa fa-angle-down"></i></a>
                                 <ul class="dropdown-menu">
                                 <li><a href="registration.php">Registration</a></li>
                                 <li><a href="log-in.php">Log in</a></li>';
                        }
                    ?>
                                        </ul>
                                    </li>




                                </ul>
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
    </header><!--/header-->

    <section id="new-event-form">
        <form action="#" method="post" name="eventform">
        <div class="container">
            <h1>Edit an event</h1>
            <div class="row">
                <div style="height: 400px;" id="map-canvas"></div>
            </div>

<?php
        $req = Event::getEventFromId($_SESSION['event_id']);
        $data = $req->fetch();            
?>            
            <div class="row">
                <div class="col-sm-1">
                    <label for="place">Place:</label>
                </div>
                <div class="col-sm-5">
                    <input class="form-control" name="place" type="text" id="place" value="<?php echo $data['event_place'];?>" required=""/>
                </div>
                <div class="col-sm-1">
                    <label for="address">Address:</label>
                </div>
                <div class="col-sm-5">
                    <input class="form-control" name="address" type="text" id="address" value="<?php echo $data['event_address'];?>" required=""/>
                </div>
            </div>            
            <div class="row">
                <div class="col-sm-1">
                    <label for="date">Date:</label>
                </div>
                <div class="col-sm-5">
                    <input  class="form-control" type="date" name="event_date" id="event_date" value="<?php echo $data['event_date'];?>" required/>
                </div>
                <div class="col-sm-1">
                    <label for="time">Time:</label>
                </div>
                <div class="col-sm-5">
                    <input  class="form-control" type="time" name="event_time" id="event_time" value ="<?php echo $data['event_time'];?>" required/>
                </div>
            </div>
            <br/>
            <div class="row">
                <div class="col-sm-4"><label for="maxpers">Number maximum of person:</label></div>
                <div class="col-sm-2">
                    <input class="form-control" type="number" name="maxpers" id="maxpers" min="2" max="1000" value="<?php echo $data['event_max'];?>" required/> 
                </div>
                <div class="col-sm-3"><label for="typeevent">Type of event:</label></div>
                <div class="col-sm-3">      
                     <input name="event_type" list="event_type" type="text" class="form-control" value="<?php echo $data['event_type'];?>" required/>
                      <datalist id="event_type">
                         <option value="Tourism" label="Tourism">
                         <option value="Sport"  label="Sport">
                         <option value="Party"  label="Party"> 
                         <option value="Nature"  label="Nature">
                      </datalist>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4"><label for="description">Description:</label></div>
                <div class="col-sm-8">      
                    <textarea name="description" id="description" rows="4"><?php echo $data['event_description'];?></textarea>
                </div>
            </div>
            <div class="row">
              <div class="dropzone" class="col-sm-12" id="dropzone">Drop the event image here to upload (NB: if you drop multiple files, only the first one will be used).<br/>
                Authorized types: gif/jpeg/jpg/png<br/>
                <img src="<?php echo $data['event_img_path'];?>" alt="No event image" class="img_droped" />
              </div>
            </div>
            <input type="hidden" name="userAction" value="new_event"/>
            <input type="hidden" name="imgPath" id="imgPath" value="<?php echo $data['event_img_path'];?>"/>
            <input style="float:right;" type="submit" onclick="add_event()" name="submit" value="SUBMIT" class="btn btn-primary">
        </div>
        </form>
    </section><!--/#all-events-->

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-10">
                    &copy; 2015 <a href="http://www.macs.hw.ac.uk/">MSc students</a>. All Rights Reserved.
                </div>
                <div class="col-sm-1 pull-right">
                    <a href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F~ft2%2Fnet-app%2Fadd-event.php">
                        <img style="border:0;width:88px;height:31px" src="images/w3c.png" alt="valid HTML!"/>
                    </a>
                </div>
                <div class="col-sm-1 pull-right">
                <p>
                    <a href="http://jigsaw.w3.org/css-validator/validator?uri=http%3A%2F%2Fwww2.macs.hw.ac.uk%2F%7Eft2%2Fnet-app%2Fadd-event.php&amp;profile=css3&amp;usermedium=all&amp;warning=1&amp;vextwarning=">
                        <img style="border:0;width:88px;height:31px"
                            src="http://jigsaw.w3.org/css-validator/images/vcss"
                            alt="Valid CSS!" />
                    </a>
                </p>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/fileupload.js"></script>
</body>
</html>