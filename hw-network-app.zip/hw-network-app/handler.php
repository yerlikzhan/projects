<?php
include_once 'db_connect.php'; 


if(!empty($_COOKIE['username']))
{

 	
	//$query = "SELECT * FROM users_profiles WHERE username='".mysql_real_escape_string($_COOKIE['username'])."' AND password='".mysql_real_escape_string($_COOKIE['password'])."'";
	//$query = "SELECT * FROM users_profiles WHERE username=? AND password=?";
	$req = $db->prepare('SELECT * FROM users_profiles WHERE username=?');
	$req->execute(array($_COOKIE['username']));

	//$search_user = $db->query($query);
	
	//$user = (mysql_num_rows($search_user) == 1) ? mysql_fetch_array($search_user) : 0;
	
	$user = $req->fetch(PDO::FETCH_ASSOC);

	$user1 = ($_COOKIE['username']);



}
else
{
	$user = 0;
}
?>