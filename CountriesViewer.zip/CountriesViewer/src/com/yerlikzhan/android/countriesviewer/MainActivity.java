package com.yerlikzhan.android.countriesviewer;

import java.util.Scanner;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.net.Uri;
import android.database.Cursor;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends FragmentActivity implements LoaderManager.LoaderCallbacks<Cursor> 
{
	TextView countryTable = null;
    CursorLoader cursorLoader;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		countryTable = (TextView) findViewById(R.id.capital);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void onClickFind(View view) 
	{
		countryTable.setText(null);
		getSupportLoaderManager().initLoader(1, null, this);
	}

	@Override
	public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) 
	{
		cursorLoader = new CursorLoader(this, Uri.parse("content://com.yerlikzhan.provider.CountryProv/countries"), null, null, null, null);
		return cursorLoader;
	}

	@Override
	public void onLoadFinished(Loader<Cursor> arg0, Cursor cursor) 
	{
		cursor.moveToFirst();
		String res = "";
        while (!cursor.isAfterLast())
        {	        	
        	res +=  cursor.getString(cursor.getColumnIndex("country")) + "," + cursor.getString(cursor.getColumnIndex("information"));
        	res += "\n";
        	cursor.moveToNext();
        }
        readLine(res);
	}
	
	public void readLine(String table)
	{
		Scanner scanner = new Scanner(table);
		String cond = ((EditText)findViewById(R.id.find)).getText().toString().trim();
		while (scanner.hasNextLine()) 
		{
			//read first line and process it
			String inputLine = scanner.nextLine(); 
			if (inputLine.length() != 0) 
			{
				//ignored if blank line
				String parts [] = inputLine.split(",");
				String country = parts[0];
				String capital = parts[1];
				String continent = parts[2];
				String area = parts[3];
				String population = parts[4];
				String language = parts[5];
				if (country.equals(cond))
				{
					countryTable.setText(capital + "\n" + area + "\n" + population
							+ "\n" + language + "\n" + continent);
					break;
				}
			}
		}		
		scanner.close();
		if (countryTable.getText().length() == 0)
		{
			Toast.makeText(getBaseContext(), "Country is not in the database", Toast.LENGTH_LONG).show();
			((EditText)findViewById(R.id.find)).setText("");
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0)
	{
		//Auto-generated method stub
	}
	
	@Override
	public void onDestroy() 
	{
        super.onDestroy();
    }
	
	public void close(View view)
	{
		finish();
	}
}
