/** Automatically generated file. DO NOT MODIFY */
package com.yerlikzhan.android.countriesviewer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}