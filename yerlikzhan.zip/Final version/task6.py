#Sabyruly Yerlikzhan
from tkinter import *
# importing classes from other tasks
from task2 import Task2
from task3 import Task3
from task4 import Task4
from task5 import Task5

task2 = Task2()
task3 = Task3()
task4 = Task4()
task5 = Task5()

class mainFrame(object): 

  # initialization of the frame 
  def __init__(self, master):
    # method from Task2 class to parse json file line by line
    self.newList = task2.parseJson('data_1.json')
    self.dataBook = task2.createDataBase(self.newList)    
    self.master = master
    # creating frame
    self.frame = Frame(self.master)
    self.newLabel = Label(self.frame, text='Enter the user or document uuid')
    self.taskLabel = Label(self.frame, text='Tasks')
    # text box for input data
    self.txtBox = Entry(self.frame)
    self.newLabel.pack(side=TOP)
    self.txtBox.pack(padx=5)
    self.taskLabel.pack()
    # buttons with task names as text
    self.task2a = Button(self.frame, text="Task 2a", command=self.showCountries)      
    self.task2b = Button(self.frame, text="Task 2b", command=self.showContinents)      
    self.task3a = Button(self.frame, text="Task 3a", command=self.browserOccurencies)
    self.task3b = Button(self.frame, text="Task 3b", command=self.showAllBrowsers)      
    self.task4 = Button(self.frame, text="Task 4", command=self.printReaders)   
    self.frame1 = Frame(master)      
    self.task5a = Button(self.frame1, text="Task 5a", command=self.getReadersByDocUUID)
    self.task5b = Button(self.frame1, text="Task 5b", command=self.getDocsByUserUUID)
    self.task5c = Button(self.frame1, text="Task 5c", command=self.getAlsoLikeByDocumen)
    self.task5d = Button(self.frame1, text="Task 5d", command=self.getAlsoLikesSortedByReadTime)
    self.task5e = Button(self.frame1, text="Task 5e", command=self.getAlsoLikesSortedByReaders)
    self.task5f = Button(self.frame1, text="Task 5f", command=self.printTop10readedDocs)
    # packing buttons and frame
    self.task2a.pack(side=LEFT)
    self.task2b.pack(side=LEFT)
    self.task3a.pack(side=LEFT) 
    self.task3b.pack(side=LEFT)
    self.task4.pack(side=LEFT)
    self.task5a.pack(side=LEFT)
    self.task5b.pack(side=LEFT)
    self.task5c.pack(side=LEFT)
    self.task5d.pack(side=LEFT)
    self.task5e.pack(side=LEFT)
    self.task5f.pack(side=LEFT)
    self.frame.pack()
    self.frame1.pack()
    self.bottomFrame = Frame(master)
    self.bottomFrame.pack(side=BOTTOM)
    self.quit = Button(self.bottomFrame, text="Quit", command=root.destroy)
    self.quit.pack(side=BOTTOM)

  # function for call function from Task2 class to make histogram of countries
  def showCountries(self):
    doc_uuid = self.txtBox.get()
    if len(doc_uuid) > 0:
      doc_c = task2.countriesDictionaryByDoc(self.dataBook, doc_uuid)
      return task2.visitersCountries(doc_c, 10)
    else:
      graph = task2.countriesDictionary(self.dataBook)
      return task2.visitersCountries(graph, 70)
  
  # function for call function from Task2 class to make histogram of continents
  def showContinents(self):
    cntries = task2.countriesDictionary(self.dataBook)
    continents = task2.getDictionaryOfContinents('countries.json')
    cnts = task2.visitersContinents(continents, cntries, 'continents.json')
    doc_uuid = self.txtBox.get()
    doc_c = task2.countriesDictionaryByDoc(self.dataBook, doc_uuid)
    if len(doc_uuid) > 0:      
      conts = task2.visitersContinents(continents, doc_c, 'continents.json')
      return task2.visitersContinentsGraph(conts)
    else:
      return task2.visitersContinentsGraph(cnts)

  # function to call function from Task3 class to show al browsers histogram with all details
  def browserOccurencies(self):
    browsers = task3.userAgentOccurencies(self.dataBook)
    return task3.makeHistogram(browsers)       

  # function to call function from Task3 class to show al browsers histogram grouped by name
  def showAllBrowsers(self):
    tmp = task2.parseJson('issuu_cw2.json')
    return task3.userBrowsersAll(tmp)
        
  # function to call function from Task4 class to display top 10 readers
  def printReaders(self):
    return task4.topReaders(self.newList)
  
  # function to call function from Task5 class to display list of reders specified by document uuid
  def getReadersByDocUUID(self):
    doc_uuid = self.txtBox.get()
    result = task5.allReadersByDocUUID(self.newList, doc_uuid)
    return task5.printAllReaders(result)
  
  # function to call function from Task5 class to display list of documents by specified used uuid
  def getDocsByUserUUID(self):
    user_uuid = self.txtBox.get()
    result = task5.alldocsByUserUUID(self.newList, user_uuid)
    return task5.printAllReaders(result)

  # function to call function from Task5 class to display 
  # list of also likes documents that readers also read
  def getAlsoLikeByDocumen(self):
    doc_uuid = self.txtBox.get()
    result = task5.alsoLikeByDocUUID(self.newList, doc_uuid)
    return task5.printAlsoLikeDocs(result)

  # function to call function from Task5 class to display 
  # list of also likes documents that readers also read sorted by readership
  def getAlsoLikesSortedByReadTime(self):
    doc_uuid = self.txtBox.get()
    dic = task5.sortByReadership(self.newList, doc_uuid)
    return task5.printSortedAlsoLikes(dic)

  # function to call function from Task5 class to display 
  # list of also likes documents that readers also read sorted by read time
  def getAlsoLikesSortedByReaders(self):
    doc_uuid = self.txtBox.get()
    dic = task5.sortByCountOfReaders(self.newList, doc_uuid)
    return task5.printSortedAlsoLikesByReaders(dic)

  # function to call function from Task5 class to display Top 10
  # list of also likes documents that readers also read sorted by readership and read time
  def printTop10readedDocs(self):
    doc_uuid = self.txtBox.get()
    dic1 = task5.sortByReadership(self.newList, doc_uuid)
    dic2 = task5.sortByCountOfReaders(self.newList, doc_uuid)
    return task5.printOutSorted(dic1, dic2)

#create main window
root = Tk()
start = mainFrame(root)
# set size of window
root.geometry('400x150')
# title of window
root.title("Sabyruly Yerlikzhan")
