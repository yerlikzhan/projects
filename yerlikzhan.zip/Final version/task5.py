from collections import OrderedDict

class Task5(object):
    #function to make a list of readers by specified document uuid
    def allReadersByDocUUID(self, dic, doc_id):
        newls = []
        for i in range(len(dic)):
            for v in dic[i]:
                if (v == "subject_doc_id"):
                    if (doc_id == dic[i][v]):
                        a = dic[i]["visitor_uuid"]
                        if a not in newls:
                            newls.append(a)
        return newls

    #function to make a list of documents by specified user uuid
    def alldocsByUserUUID(self, dic, user_id):
        newls = []
        for i in range(len(dic)):
            for v in dic[i]:
                if (v == "visitor_uuid"):
                    if (dic[i]["env_type"] == "reader"):
                        if (user_id == dic[i][v]):
                            a = dic[i]["subject_doc_id"]
                            if a not in newls:
                                newls.append(a)
        return newls

    #function to make a list of documents that readers of the specified document uuid also read
    def alsoLikeByDocUUID(self, dic, doc_id):
        likers = self.allReadersByDocUUID(dic, doc_id)
        alsoLike = []
        for i in likers:
            a = self.alldocsByUserUUID(dic, i)
            for b in a:
                if b not in alsoLike:
                    if (b != doc_id):
                        alsoLike.append(b)
        return alsoLike   

    #function to make a ditionary of documents that readers of the specified document uuid also read 
    #sorted by read time of the document, amount of time as values
    def sortByReadership(self, dic, doc_id):
        readers = {}
        fav = self.alsoLikeByDocUUID(dic, doc_id)
        for y in fav:
            for i in range(len(dic)):
                for v in dic[i]:
                    if (v == "event_readtime"):
                        if (dic[i]["subject_doc_id"] == y):
                            if y in readers:
                                readers[y] = readers[y] + dic[i][v]
                            else:
                                readers[y] = dic[i][v]
        return readers        

    #function to make a dictionary of documents that readers of the specified document uuid also read 
    #sorted by amount of reders of the document, amount of reders as values
    def sortByCountOfReaders(self, dic, doc_id):
        readers = {}
        temp = []
        fav = self.alsoLikeByDocUUID(dic, doc_id)
        for y in fav:
            t = self.allReadersByDocUUID(dic, y)
            readers[y] = len(t)            
        return readers

    #function to print out documents/users list
    def printAllReaders(self, resultList):
        f = 0
        if (len(resultList) == 0):
            print("can't find, you entered invalid data\n")
        else:
            if (len(resultList[0]) > 16):
                print ("The list of documents that reader read:\n")
            else:
                print ("The list of users that read this document:\n")
            for b in resultList:
                f = f + 1
                print ("%s) %s" % (f, b))
            print("\n")

    # function to print out the list of also likes list
    def printAlsoLikeDocs(self, resultList):
        f = 0
        if (len(resultList) == 0):
            print("The readers of input document didn't read any other document's\n")
        else:
            print ("The documents that also likes to readers of input document:\n")
            for b in resultList:
                f = f + 1
                print ("%s) %s" % (f, b))
            print("\n")

    # function to print also likes dictionary sorted by values (readership)
    def printSortedAlsoLikes(self, dic):
        sortedDic = OrderedDict(sorted(dic.items(), key=lambda x: x[1], reverse=True))
        if (len(dic) == 0):
            print ("The readers of input document didn't read any other document's\n")
        else:
            f = 1
            print ("The documents that also likes to readers of input document sorted by reading time:\n")
            for k, v in sortedDic.items():
                print ("%s) %s:  %s sec" % (f, k, v/1000))
                f = f + 1
            print("\n")

    # function to print also likes dictionary sorted by values (amount of reders)
    def printSortedAlsoLikesByReaders(slef, dic):
        sortedDic = OrderedDict(sorted(dic.items(), key=lambda x: x[1], reverse=True))
        if (len(dic) == 0):
            print ("The readers of input document didn't read any other document's\n")
        else:
            f = 1
            print ("The documents that also likes to readers of input document sorted by the number of readers:\n")
            for k, v in sortedDic.items():
                print ("%s) %s:  %s" % (f, k, v))
                f = f + 1
            print("\n")

    # function to print Top ten documents from also likes dictionary (readership)
    def top10sortedTime(self, dic):
        sortedDic = OrderedDict(sorted(dic.items(), key=lambda x: x[1], reverse=True)[:10])
        if (len(dic) == 0):
            print ("The readers of input document didn't read any other document's\n")
        else:
            f = 1
            print ("Top 10 documents that also likes to readers of input document sorted by reading time:\n")
            for k, v in sortedDic.items():
                print ("%s) %s:  %s sec" % (f, k, v/1000))
                f = f + 1
            print("\n")

    # function to print Top ten documents from also likes dictionary (amount of reders)
    def top10sortedReaders(self, dic):
        if (len(dic) > 0):
            f = 1
            sortedDic = OrderedDict(sorted(dic.items(), key=lambda x: x[1], reverse=True)[:10])
            print ("Top 10 documents that also likes to readers of input document sorted by amount of readers:\n")
            for k, v in sortedDic.items():
                print ("%s) %s:  %s" % (f, k, v))
                f = f + 1
            print("\n")                

    # function to print both Top also likes documents (redership and amount of time) by one click
    def printOutSorted(self, dic1, dic2):
        self.top10sortedTime(dic1)
        self.top10sortedReaders(dic2)