#Sabyruly Yerlikzhan
from collections import OrderedDict

class Task4(object):
	#function to make a dictionary of top readers and sort it by time, time in seconds as values
	def topReaders(self, dic):		
		readers = {}
		count = 1
		for i in range(len(dic)):
			for v in dic[i]:
				if (v == 'event_readtime'):
					y = dic[i]['visitor_uuid']
					if y in readers:
						readers[y] = readers[y] + dic[i][v]
					else:
						readers[y] = dic[i][v]
		print ('Top 10 readers:\n', '\nvisitor_uuid', '     ', 'event_readtime')		
		sortedDic = OrderedDict(sorted(readers.items(), key=lambda x: x[1], reverse=True))
		for k, v in sortedDic.items():
			if count <=10:
				print ("%s) %s:  %s sec" % (count, k, v/1000))
				count += 1
		print("\n")