#Sabyruly Yerlikzhan
import matplotlib.pyplot as plt
import pandas

class Task3(object):
	# function to make a dicionary of user agents with amount of occuriencies as a values
	def userAgentOccurencies(self, dic):
		browsers = {}
		a = 'visitor_useragent'
		for i in range(len(dic)):
			for v in dic[i]:
				if (v == a):
					if (dic[i][v] in browsers):
						browsers[dic[i][v]] = browsers[dic[i][v]] + 1
					else:
						browsers[dic[i][v]] = 1
		return browsers

	# function to make histogram of all browsers by specified name (version, operation system etc.)
	def makeHistogram(self, borwsers):
		plt.xlabel('user agents')
		plt.ylabel('amount of occurencies')
		plt.title('user agent occurencies by browser type')
		my_xticks = borwsers.keys()
		x = list(range(len(my_xticks)))
		y = list(borwsers.values())
		plt.plot(x, y)
		plt.xticks(rotation=90)
		plt.xticks(x, list(my_xticks))
		plt.grid(True)
		plt.show()

	# function to make histogram of user's browsers by name
	def userBrowsersAll(self, newList):
		v = 'visitor_useragent'
		for i in range(len(newList)):
			newList[i][v] = newList[i][v].split('/')[0]
		df = pandas.DataFrame(newList)
		grouped = df.groupby(v)
		grouped[v].agg(['count']).plot(kind='bar')
		plt.xticks(rotation=0)
		plt.xlabel('user agents')
		plt.ylabel('amount of occurencies')
		plt.title('user agent occurencies by browser name')
		plt.show()