#Sabyruly Yerlikzhan
import getopt
from tkinter import *
from task6 import root
from task6 import start

class CW2(object):

	user_uuid = None
	document_uuid = None
	taskID = None

	def __init__(self, argv):
		try:
			#read arguments from command line
			cmdLine, args = getopt.getopt(argv[1:],"u:d:t:")
		except:
			#if arguments incorect
			print("\nGiven arguments are incorrect")

		# specifieng input arguments
		for key, value in cmdLine:
			if key == "-u":
				self.user_uuid = value
			if key == "-d":
				self.document_uuid = value
			if key == "-t":
				self.taskID = value	
		# expect arguments on runtime
		self.run(self.user_uuid, self.document_uuid, self.taskID)

	# function to declare values of given arguments from command line
	def run(self, user_uuid, document_uuid, taskID):
		# start task2a		
		if (taskID == "task2a" and document_uuid is not None):
			start.txtBox.insert(INSERT, document_uuid)
			start.showCountries()	

		# start task2b
		elif (taskID == "task2b" and document_uuid is not None):
			start.txtBox.insert(INSERT, document_uuid)
			start.showContinents()	

		# start task3a
		elif (taskID == "task3a"):
			start.browserOccurencies()			

		# start task3b
		elif (taskID == "task3b"):
			start.showAllBrowsers()			

		# start task4
		elif (taskID == "task4"):
			start.printReaders()
		# start task5a
		elif (taskID == "task5a" and document_uuid is not None):
			start.txtBox.insert(INSERT, document_uuid)
			start.getReadersByDocUUID()

		# start task5b
		elif (taskID == "task5b" and user_uuid is not None):
			start.txtBox.insert(INSERT, user_uuid)
			start.getDocsByUserUUID()

		# start task5c	
		elif (taskID == "task5c" and document_uuid is not None):
			start.txtBox.insert(INSERT, document_uuid)
			start.getAlsoLikeByDocumen()
	
		# start task5d
		elif (taskID == "task5d" and document_uuid is not None):
			start.txtBox.insert(INSERT, document_uuid)
			start.getAlsoLikesSortedByReadTime()
	
		# start task5e
		elif (taskID == "task5e" and document_uuid is not None):
			start.txtBox.insert(INSERT, document_uuid)
			start.getAlsoLikesSortedByReaders()
	
		# start task5f
		elif (taskID == "task5f" and document_uuid is not None):
			start.txtBox.insert(INSERT, document_uuid)
			start.printTop10readedDocs()
		
		# if the arguments not given, just run the application
		elif(user_uuid is None and document_uuid is None and taskID is None):
			pass

		# if given arguments incorrect display the message and run application
		else:
			print("\nGiven arguments are incorrect")

#expect arguments
CW2(sys.argv)
#display the main window
root.mainloop()