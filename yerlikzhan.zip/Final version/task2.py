#Sabyruly Yerlikzhan
import json
import matplotlib.pyplot as plt

class Task2(object):

	#function to parse json file line by line and add it to the list
	def parseJson(self, file):
		data = []
		with open(file) as f:
			for line in f:
				data.append(json.loads(line))
		return data
	
	#make a dictionary from the list
	def createDataBase(self, newList):
		book ={}
		dic = []
		for i in range(len(newList)):			
			book = newList[i]
			dic.append(book)
		return dic

	#return the countries of the viewers with number ov occurencies as a key values
	def countriesDictionary(self, dic):
		countries = {}
		for i in range(len(dic)):
			for v in dic[i]:
				if (v == 'visitor_country'):
					if (dic[i][v] in countries):
						countries[dic[i][v]] = countries[dic[i][v]] + 1
					else:
						countries[dic[i][v]] = 1
		return countries

	#return the countries of the viewers of the specified document
	def countriesDictionaryByDoc(self, dic, doc_uuid):
		countries = {"country" : 0}
		for i in range(len(dic)):
			for v in dic[i]:
				if (v == 'subject_doc_id'):
					if (doc_uuid == dic[i][v]):
						a = 'visitor_country'
						if (dic[i][a] in countries):
							countries[dic[i][a]] = countries[dic[i][a]] + 1
						else:
							countries[dic[i][a]] = 1
		return countries	

	#function to create a histogram
	def visitersCountries(self, countries, size):
		if len(countries) > 1:
			plt.xlabel('Countries')
			plt.ylabel('Counter')
			plt.title('Countries Histogram')
			my_xticks = countries.keys()
			x = list(range(len(my_xticks)))
			y = list(countries.values())
			n, bins, patches = plt.hist( x, size, weights=y, histtype='bar')
			#plt.plot(x, y)
			plt.xticks(rotation=90)
			plt.xticks(x, list(my_xticks))
			plt.grid(True)
			plt.show()
		else:
			print("Incorrect document uuid")

	#create a dictionary of contitnents, parsing json file with specified data
	def getDictionaryOfContinents(self, file):
		continents = {}
		data = self.parseJson(file)
		continents = data[0]
		return continents

	#make a histogram of continents of the viewers
	def visitersContinentsGraph(self, continents):
		plt.xlabel('Continents')
		plt.ylabel('Counter')
		plt.title('Continents Histogram')
		my_xticks = continents.keys()
		x = list(range(len(my_xticks)))
		y = list(continents.values())
		if (sum(y) > 0):
			n, bins, patches = plt.hist(x, 20, weights = y, histtype = 'bar')
			#plt.plot(x, y)
			plt.xticks(rotation=15)
			plt.xticks(x, list(my_xticks))
			plt.grid(True)
			plt.show()
		else:
			print("Incorrect document uuid")

	#function to make a list of continents of the viewers
	def visitersContinents(self, dicti, countryList, file):
		lst = self.parseJson(file)
		contsDic = lst[0]
		for a in dicti:		
			if a in countryList:
				if (dicti[a] == "EU"):
					contsDic["Europe"] = contsDic["Europe"] + countryList[a]
				elif (dicti[a] == "AF"):
					contsDic["Africa"] = contsDic["Africa"] + countryList[a]
				elif (dicti[a] == "AS"):
					contsDic["Asia"] = contsDic["Asia"] + countryList[a]
				elif (dicti[a] == "NA"):
					contsDic["North America"] = contsDic["North America"] + countryList[a]
				elif (dicti[a] == "SA"):
					contsDic["South America"] = contsDic["South America"] + countryList[a]
				elif (dicti[a] == "OC"):
					contsDic["Oceania"] = contsDic["Oceania"] + countryList[a]
				elif (dicti[a] == "AN"):
					contsDic["Antarctica"] = contsDic["Antarctica"] + countryList[a]
		return contsDic