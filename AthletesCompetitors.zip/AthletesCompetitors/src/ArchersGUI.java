//import all the GUI classes
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class ArchersGUI extends JFrame implements ActionListener
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// The staff list to be searched.
    private AthletesList athletesList;       
    JTextField result;
    JTextField searchField;
    JButton search;
    JScrollPane scrollList;
    JButton showListById, showListByName, swowListByScores, close, showWinner;
    JTextArea displayList;   
    
    /**
     * Create the frame with its panels.
     * @param list	The staff list to be searched.
     */   
    public ArchersGUI(AthletesList list)
    {
        this.athletesList = list;        
        //set up window title
        setTitle("Archers");     
		setupNorthPanel();
		setupCenterPanel();
        //pack and set visible
        pack();
        setVisible(true);     
    } 
    
    
    private void setupCenterPanel()
    {
        displayList = new JTextArea(20,100);
        displayList.setFont(new Font (Font.MONOSPACED, Font.PLAIN,14));
        displayList.setEditable(false);
        displayList.setText(athletesList.ArchersjFrame());
        scrollList = new JScrollPane(displayList);
        this.add(scrollList,BorderLayout.CENTER);
    }    
    
    private void setupNorthPanel()
    {
        //add north panel containing some buttons
        JPanel northPanel = new JPanel();
        showWinner = new JButton("Winner");
        showWinner.addActionListener(this);
        
        showListById = new JButton("Sort By AN");
        showListById.addActionListener(this);
        
        showListByName = new JButton("Sort By First Name");
        showListByName.addActionListener(this);
        
        swowListByScores = new JButton("Sort By Scores");
        swowListByScores.addActionListener(this);
        
        close = new JButton("Close");
        close.addActionListener(this);
        
        northPanel.add (showWinner);
        northPanel.add (showListById);
        northPanel.add(showListByName);
        northPanel.add (swowListByScores);
        northPanel.add(close);
        this.add(northPanel, BorderLayout.NORTH);
    }
    
    //come here when button is clicked
    //find which button and act accordingly
    public void actionPerformed(ActionEvent e) 
    { 
    	if (e.getSource() == showListById) 
    	{
    		displayList.setText(athletesList.listByArcherID());
    	}
    	else if (e.getSource() == showWinner )
    	{
    		JOptionPane.showMessageDialog(this, "The Winner is: " + athletesList.getArcherWithMax() +
    				" with overall score - " + athletesList.getArcherMaxOverall());
    	}
    	else if (e.getSource() == showListByName ) 
    	{
    		displayList.setText(athletesList.listByArcherName());
    	}
    	else if (e.getSource() == swowListByScores) 
    	{    		    		
    		displayList.setText(athletesList.listByArcherScores());
    	}
    	else if (e.getSource() == close) 
    	{    		    		
            setVisible(false);
    	}   	
    }
}
