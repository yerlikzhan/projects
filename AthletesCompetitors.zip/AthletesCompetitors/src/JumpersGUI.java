//import all the GUI classes
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Simple GUI for StaffList application
 */
public class JumpersGUI extends JFrame implements ActionListener
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// The staff list to be searched.
    private AthletesList athletesList;       
    JTextField result;
    JTextField searchField;
    JButton search;
    JScrollPane scrollList;
    JButton showListById, showListByName, swowListByScores, close;
    JTextArea displayList;   
    
    /**
     * Create the frame with its panels.
     * @param list	The staff list to be searched.
     */
    
    public JumpersGUI(AthletesList list)
    {
        this.athletesList = list;        
        //set up window title
        setTitle("Jumpers");
		setupSouthPanel();
		setupNorthPanel();
		setupCenterPanel();
        //pack and set visible
        pack();
        setVisible(true);
        result.setText("Result of search will appear here");
    }    
    
    private void setupCenterPanel()
    {
        displayList = new JTextArea(20,120);
        displayList.setFont(new Font (Font.MONOSPACED, Font.PLAIN,14));
        displayList.setEditable(false);
        displayList.setText(athletesList.JumpersjFrame());
        scrollList = new JScrollPane(displayList);
        this.add(scrollList,BorderLayout.CENTER);
    }
    
    private void setupSouthPanel()
    {
        //search panel contains label, text field and button
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new GridLayout(1,3));
        searchPanel.add(new JLabel("Enter Competitor Number"));   
        searchField = new JTextField(5);
        searchPanel.add(searchField);   
        search = new JButton("Search");  
        searchPanel.add(search);    
        //specify action when button is pressed
        search.addActionListener(this) ;
        
        //Set up the area where the results will be displayed.
        result= new JTextField(40);     
        result.setEditable(false);
        
        //set up south panel containing 2 previous areas
        JPanel southPanel = new JPanel();
        southPanel.setLayout(new GridLayout(3,1));
        southPanel.add(searchPanel);
        southPanel.add(result);        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1,3));
        southPanel.add(buttonPanel);         
       
        //add south panel to the content pane
        this.add(southPanel, BorderLayout.SOUTH);   	
    }
    
    private void setupNorthPanel()
    {
        //add north panel containing some buttons
        JPanel northPanel = new JPanel();
        showListById = new JButton("Sort By JN");
        showListById.addActionListener(this);
        
        showListByName = new JButton("Sort By First Name");
        showListByName.addActionListener(this);
        
        swowListByScores = new JButton("Sort By Scores");
        swowListByScores.addActionListener(this);
        
        close = new JButton("Close");
        close.addActionListener(this);
        
        northPanel.add (showListById);
        northPanel.add(showListByName);
        northPanel.add (swowListByScores);
        northPanel.add(close);
        this.add(northPanel, BorderLayout.NORTH);
    }
    
    //come here when button is clicked
    //find which button and act accordingly
    public void actionPerformed(ActionEvent e) 
    {   
    	if (e.getSource() == search) 
    	{
    		search();
    	}
    	else if (e.getSource() == showListById) 
    	{
    		displayList.setText(athletesList.listByJumperID());
    	}
    	else if (e.getSource() == showListByName ) 
    	{
    		displayList.setText(athletesList.listByJumperName());
    	}
    	else if (e.getSource() == swowListByScores) 
    	{    		    		
    		displayList.setText(athletesList.listByJumperScores());
    	}
    	else if (e.getSource() == close) 
    	{    		    		
            setVisible(false);
    	}    	
    }  
  
    private void search()
    {
    	//get search text and search staff list
    	//setting result text 
    	String search = searchField.getText().trim();
    	String person = "";   	
    	
    	if (search.length() > 0)
    	{
    		result.setText("competitor not found");
    		int searchString = Integer.parseInt(searchField.getText());    		
    		person = athletesList.findByJumperNumber(searchString);
    		if (person != null )
    		{
    			result.setText(person.toString());    				
    		}
    	}    		
    	else 
    	{
    		result.setText("no text entered");
    	}
    }
}
