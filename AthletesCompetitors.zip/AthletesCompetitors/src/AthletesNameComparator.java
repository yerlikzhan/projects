//defines an ordering on Staff objects on the name

import java.util.Comparator;
public class AthletesNameComparator implements Comparator<Athletes>
{
	public int compare(Athletes a1, Athletes a2) 
	{
		return a1.getName().getFirstName().compareTo(a2.getName().getFirstName());
	}
	

}
