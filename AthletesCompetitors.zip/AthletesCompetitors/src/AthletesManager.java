import java.io.*;

public class AthletesManager
{
	private AthletesList athletesList;
	
    public AthletesManager() 
    {
    	//Initialize empty list of staff
        athletesList = new AthletesList();
        addAthletes();
        
    }
    
    private void addAthletes() 
    {
        //load staff data from file
        BufferedReader archerBuff = null;
        BufferedReader jumperBuff = null;
        BufferedReader swimmerBuff = null;
        try 
        {
        	archerBuff = new BufferedReader(new FileReader("TableOfCompetitors.csv"));
	    	String inputArcherLine = archerBuff.readLine();  //read first line
	    	while(inputArcherLine != null)
	    	{  
	    		processAthletesLine(inputArcherLine);
	            //read next line
	            inputArcherLine = archerBuff.readLine();
	        }
	    	
        	jumperBuff = new BufferedReader(new FileReader("JumpersCompetitors.csv"));
	    	String inputJumperLine = jumperBuff.readLine();  //read first line
	    	while(inputJumperLine != null)
	    	{  
	    		processAthletesLine(inputJumperLine);
	            //read next line
	            inputJumperLine = jumperBuff.readLine();
	        }
	    	
	    	swimmerBuff = new BufferedReader(new FileReader("SwimmerList.csv"));
	    	String inputSwimmerLine = swimmerBuff.readLine();  //read first line
	    	while(inputSwimmerLine != null)
	    	{  
	    		processAthletesLine(inputSwimmerLine);
	            //read next line
	            inputSwimmerLine = swimmerBuff.readLine();
	        }
        }
        catch(FileNotFoundException e) 
        {
        	System.out.println(e.getMessage());
            System.exit(1);
        }
        catch (IOException e) 
        {
        	e.printStackTrace();
            System.exit(1);        	
        }
        finally  
        {
        	try
        	{
        		archerBuff.close();
        	}
        	catch (IOException ioe) 
        	{
        		//don't do anything
        	}
        }   	
    }
    
    private void processAthletesLine(String line) 
	{
		try
		{			
			String values [] = line.split(",");			
			String competNumber = values[0];
			competNumber = competNumber.trim();
			int cNumber = Integer.parseInt(competNumber);
			Name name = new Name(values[1]);
			String lvl = values[2];
			lvl = lvl.trim();			
			String attribute = values[3];
			//the scores are at the end of the line
			int scoreLength = values.length - 4;		
			String sc[] = new String[scoreLength];
			System.arraycopy(values, 4, sc, 0, scoreLength);
			int scores[] = new int[sc.length];
			//converting string[] into int[]
			for(int i = 0;i < scores.length;i++)
			{			   
			   scores[i] = Integer.parseInt(sc[i]);
			}				
			int age = 0;
			if (scores.length == 6)
			{
				//create Archer object and add to the list
				Archer a = new Archer(cNumber, name, lvl, attribute, scores);
				athletesList.add(a);
			}
			else
			{
				try
				{
					age = Integer.parseInt(lvl);
				}
				catch(NumberFormatException ex)
				{					
					{
					Swimmer s = new Swimmer(cNumber, name, lvl, attribute, scores);
					athletesList.add(s);
					}
				}
				if(age > 0)
				{
					Jumper j = new Jumper(cNumber, name, age, attribute, scores);
					athletesList.add(j);
				}
			}
		}
		
		//for these two formatting errors, ignore lines in error and try and carry on
		//this catches trying to convert a String to an integer
		catch (NumberFormatException nfe)
		{
			String error = "Number conversion error in '" + line + "'  - " 
			                  + nfe.getMessage();
			System.out.println(error);
		}
		
		//this catches missing items if only one or two items
		//other omissions will result in other errors
		catch (ArrayIndexOutOfBoundsException air)
		{
			String error = "Not enough items in  : '" + line
			                        + "' index position : " + air.getMessage();
			System.out.println(error);
		}
	}
    
    //show GUIs
    private void showGUI() 
    {
    	//create main GUI with StaffList object
    	AthletesListGUI gui = new AthletesListGUI(athletesList);
        gui.setVisible(true);
    }
    
    public static void main (String arg[]) 
    {
       	//creates demo object which sets up the interface
    	//then just waits for user interaction
    	AthletesManager demo = new AthletesManager();   	
    	demo.showGUI();   	
    }    
    
}
