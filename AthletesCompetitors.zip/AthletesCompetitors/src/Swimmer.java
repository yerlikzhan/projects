/**
 * Software Engineering Foundations
 * F21SF Assignment 1
 * Swimmer class with used methods
 * @author Assem Madikenova
 */
public class Swimmer extends Athletes {

	//instance variables
	public String country;

	//constructor to create object Swimmer 
	public Swimmer(int cN, Name n, String l, String c, int [] sc) 
	{
		super(cN, n, l, sc);
		country=c;
	}
	
	public String getCountry() {return country;}
		
	//returns overall score of swimmer
	public double getOverallScore() 
	{
		int sum=0;
		for (int scoresIndex=1; scoresIndex<scores.length-1; scoresIndex++){
			sum=sum+scores[scoresIndex];
		}
		return (double) sum/3;
	}

	//returns maximum score
	public int getMaxScore()
	{
		int max=scores[0];
		for(int i=1; i<scores.length;i++)
		{
			if(scores[i]>max)max=scores[i];
		}
		return max;
	}

	//returns minimum score
	public int getMinScore(){
		int min=scores[0];
		for(int i=1; i<scores.length;i++)
		{
			if(scores[i]<min)min=scores[i];
		}
		return min;
	}

	//method returns full details about a particular swimmer
	public String getFullDetails() 
	{
		return "Swimmer number "+getCompetitorNumber()+ ", name "+ 
				competitorName.getFullName()+"."+ "\n" + competitorName.getFirstName() + " is a " + level +
				" from "+ country+ " and received following scores: "+getScoreArray()+"."+ "\n" + 
				"This gives him an overall score of "+ String.format ("%.2f", getOverallScore());
	}
	
	public String getEditDetails()
	{
		String report = "";
		report += "Swimmer number: " + getCompetitorNumber();
		report += ", full name is " + getName().getFullName();
		report += ", level is " + getLevel();
		report += ", from " + getCountry();			
		report += ", given scores: " + getScoreArray();
		report += "and overall score: " + String.format ("%.2f", getOverallScore());
				
		return report;
	}
}