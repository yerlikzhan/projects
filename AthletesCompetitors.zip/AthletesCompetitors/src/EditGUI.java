//import all the GUI classes
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Simple GUI for StaffList application
 */
public class EditGUI extends JFrame implements ActionListener
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// The staff list to be searched.
    private AthletesList athletesList;    
    JTextField result;
    JTextField editCN, editName, editLevel, editAt, editScores;
    JButton save, cancel;
    JScrollPane scrollList;
    JTextArea displayList;      
    
    /**
     * Create the frame with its panels.
     * @param list	The staff list to be searched.
     */
   
    public EditGUI(AthletesList list)
    {
        this.athletesList = list;        
        //set up window title
        setTitle("Edit Athletes information");        
		setupSouthPanel();
		setupNorthPanel();		
        //pack and set visible
        pack();
        setVisible(true);
        setDefaultCloseOperation(EditGUI.DO_NOTHING_ON_CLOSE);
        centerFrame(this);
    }
    
    private void setupSouthPanel()
    {        
        JPanel editPanel = new JPanel();
        editPanel.setLayout(new GridLayout(6,1));
       
        editPanel.add(new JLabel("Competitor Number"));   
        editCN = new JTextField(20);
        editPanel.add(editCN);
        editCN.setText(athletesList.getCompetNumber());
        
        editPanel.add(new JLabel("Name"));        
        editName = new JTextField(20);
        editPanel.add(editName);
        editName.setText(athletesList.getCompetName());
        
        editLevel = new JTextField(20);
        editPanel.add(new JLabel("Level"));        
        editPanel.add(editLevel);
        editLevel.setText(athletesList.getCompetLevel());
        
        editAt = new JTextField(20);
        editPanel.add(new JLabel("University/Age/Country"));
        editPanel.add(editAt);
        editAt.setText(athletesList.getCompetAttribute());
       
        editScores = new JTextField(20);
        editPanel.add(new JLabel("Scores"));
        editPanel.add(editScores);
        editScores.setText(athletesList.getCompetScore().trim());
             
        //set up south panel containing 2 previous areas
        JPanel southPanel = new JPanel();
        southPanel.setLayout(new GridLayout(1,1));
        southPanel.add(editPanel);        
        this.add(southPanel, BorderLayout.NORTH);        
    }
    
    private void setupNorthPanel()
    {
    	JPanel savePanel = new JPanel();
    	save = new JButton("Save");    	        
        savePanel.add(save); 
        cancel = new JButton("Cancel");
        savePanel.add(cancel);
        
        savePanel.setLayout(new GridLayout(1,2));
        //specify action when button is pressed
        save.addActionListener(this) ;
        cancel.addActionListener(this) ;
        //add north panel containing some buttons
        JPanel northPanel = new JPanel();
        northPanel.add(savePanel);
        this.add(northPanel, BorderLayout.SOUTH);        
    }
    
    //come here when button is clicked
    //find which button and act accordingly
    public void actionPerformed(ActionEvent e) 
    {       	
    	if (e.getSource() == save) 
    	{
    		save();    		
    	}
    	if (e.getSource() == cancel) 
    	{
    		this.setVisible(false);
			AthletesListGUI at = new AthletesListGUI(athletesList);
    		at.showListById.doClick();
    	}
    }
    
    public void save()
  	{
    	int comNum = Integer.parseInt(athletesList.getCompetNumber().trim());   	
    	{
    		try
    		{    			
    			int cNum = Integer.parseInt(editCN.getText());
    			Name cName = new Name(editName.getText().trim());
    			String lvl = editLevel.getText();
    			String attribute = editAt.getText();
    			String marks [] = editScores.getText().trim().split(" ");
    			int scoreLength = marks.length;	
    			String sc[] = new String[scoreLength];
    			System.arraycopy(marks, 0, sc, 0, scoreLength);
    			int scores[] = new int[sc.length]; 
    			
    			if (athletesList.getInstance().equals("Archer"))
    			{
    				if (marks.length == 6)
    				{    		
    					//converting string[] into int[]
    					for(int i = 0; i < scores.length; i++)
    					{			   
    						if (Integer.parseInt(sc[i]) > 0 && Integer.parseInt(sc[i]) < 6)
    						{
    							scores[i] = Integer.parseInt(sc[i]); 
    						}
    						else
    						{
    							scores[0] =  0;
    						}    			
    					}
    					if (scores[0] > 0)
    					{
    						if (lvl.equals("Shooter") | lvl.equals("Archer") | lvl.equals("Sniper"))
    						{
    							Archer a = new Archer(cNum, cName, lvl, attribute, scores);
    							int ind = athletesList.getIndexByCN(comNum);
    							athletesList.editList(ind, a);
    							this.setVisible(false);
    							athletesList.setCompetNumber("");
    							AthletesListGUI at = new AthletesListGUI(athletesList);
    							at.showListById.doClick();
    						}
    						else
    						{
    							JOptionPane.showMessageDialog(this, "Level should be: Shooter, Archer or Sniper");
    						}
    					}
    					else
    					{
    						JOptionPane.showMessageDialog(this, "Scores must be between 1 and 5 inclusive");
    					}
    				}
    				else
    				{
    					JOptionPane.showMessageDialog(this, "Please provide 6 scores separated by space");
    				}
    			}
    			
    			if (athletesList.getInstance().equals("Jumper"))
    	    	{
    				if (marks.length == 5)
        			{    		
        				//converting string[] into int[]
        				for(int i = 0; i < scores.length; i++)
        				{			   
        					if (Integer.parseInt(sc[i]) > 0 && Integer.parseInt(sc[i]) < 6)
        					{
        						scores[i] = Integer.parseInt(sc[i]); 
        					}
        					else
        					{
        						scores[0] =  0;
        					}    			
        				}
        				if (scores[0] > 0)
        				{        					
        					int age = Integer.parseInt(attribute);
        					Jumper a = new Jumper(cNum, cName, age, lvl, scores);
        					int ind = athletesList.getIndexByCN(comNum);
        					athletesList.editList(ind, a);
        					this.setVisible(false);
        					athletesList.setCompetNumber("");
        					AthletesListGUI at = new AthletesListGUI(athletesList);
        					at.showListById.doClick();        					
        				}
        				else
        				{
        					JOptionPane.showMessageDialog(this, "Scores must be between 1 and 5 inclusive");
        				}
        			}
        			else
        			{
        				JOptionPane.showMessageDialog(this, "Please provide 5 scores separated by space");
        			}
    	    	}
    			
    			if (athletesList.getInstance().equals("Swimmer"))
    	    	{
    				if (marks.length == 5)
        			{    		
        				//converting string[] into int[]
        				for(int i = 0; i < scores.length; i++)
        				{			   
        					if (Integer.parseInt(sc[i]) > 0 && Integer.parseInt(sc[i]) < 6)
        					{
        						scores[i] = Integer.parseInt(sc[i]); 
        					}
        					else
        					{
        						scores[0] =  0;
        					}    			
        				}
        				if (scores[0] > 0)
        				{    					
        					Swimmer a = new Swimmer(cNum, cName, lvl, attribute, scores);
        					int ind = athletesList.getIndexByCN(comNum);
        					athletesList.editList(ind, a);
        					this.setVisible(false);
        					athletesList.setCompetNumber("");
        					AthletesListGUI at = new AthletesListGUI(athletesList);
        					at.showListById.doClick();
        				}
        				else
        				{
        					JOptionPane.showMessageDialog(this, "Scores must be between 1 and 5 inclusive");
        				}
        			}
        			else
        			{
        				JOptionPane.showMessageDialog(this, "Please provide 5 scores separated by space");
        			}
    	    	}
    			
    		}
    		catch (NumberFormatException ex)
    		{
    			JOptionPane.showMessageDialog(this, "Incorrect data, please provide correct competitor number"
    					+ " and scores divided by space");
    		}
    		catch (StringIndexOutOfBoundsException n)
    		{
    			JOptionPane.showMessageDialog(this, "Incorrect data");
    		}	
    	}    	
  	}
    
    public static void centerFrame(Window frame) 
    {
        frame.setLocationRelativeTo(null);
    }   
}
