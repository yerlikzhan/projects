// Jumper class
public class Jumper extends Athletes{
	
	
	private static final int NUM_SCORES = 5;
	private int age;
	public int s1, s2, s3, s4, s5;
		
	//constructor to create object with Jumper number, name, level and score	
	public Jumper(int cNumber, Name cName, int age, String lvl, int[] scores)
	{
		super(cNumber, cName, lvl, scores);	
		this.age = age;	
	}		
	
	//returns Jumper age	 
	public int getJumperAge() {  return age;  }	
	
	//set Jumper age
	public int setJumperAge(int age) {this.age = age; return age;}	
		
	public int getFirstScore() {return s1 = scores[0];}
	public int getSecondScore()	{return s2 = scores[1];}
	public int getThirdScore() {return s3 = scores[2];}				
	public int getFourScore() {return s4 = scores[3];}	
	public int getFiveScore() {return s5 = scores[4];}				
		
	//this method returns the average score of the first three scores
	public double getOverallScore(){
		int i = 0; 
		double k = 0;	
		while (i<NUM_SCORES-2)
		{
			k+= scores[i];
			i++;
		}
		return k/3;
	}

	//this method returns full details about a chosen jumper	
	public String getFullDetails()
	{ 
		return  "Jumper number, " + getCompetitorNumber() + ", name " +
		competitorName.getFullName() + "." + "\n" + 
		competitorName.getFirstName() + 
		" is a/an " + level + " aged " + getJumperAge() + 
		" and received these scores: " + getScoreArray() + "." + "\n" + 
		"This gives him/her an overall score of the first three judges: " + String.format("%.2f", getOverallScore()) ;	
	}
		
	//in order to show that this program is used set method	
	public String getDetailsAfterSetAge()
	{
		return "After one year " + competitorName.getFirstName() + " will be " + setJumperAge(getJumperAge() + 1) + " years old";
	}
	
	public String getEditDetails()
	{
		String report = "";
		report += "Jumper number: " + getCompetitorNumber();
		report += ", full name is " + getName().getFullName();
		report += ", level is " + getLevel();
		report += ", aged " + getJumperAge();			
		report += ", given scores: " + getScoreArray();
		report += "and overall score: " + String.format ("%.2f", getOverallScore());
				
		return report;
	}

}