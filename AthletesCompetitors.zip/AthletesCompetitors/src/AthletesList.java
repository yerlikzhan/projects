import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class AthletesList
{
	private String comNumber = "";
	private String comName = "";
	private String comLevel = "";
	private String comAt = "";
	private String comSc = "";
	private String instance = "";
	private int index = 0;
	
	/**
	 * holds a list of Jumpers objects 
	 */
	public ArrayList<Athletes> athletesList;
	
	/**
	 * create an empty arraylist
	 * @return 
	 */
	public AthletesList() 
	{		
		athletesList = new ArrayList<Athletes> ();		
	}	
	
	/**
	 * return table of Jumpers including: Jumper - number, full name, age, level, scores, overall score (from first free scores)
	 * @return returns full information of Jumper competition
	 */	
	public String getTableOfAthletes()
	{		
		String report = "Short details of athletes from 3 different competitions:" + "\n" + "\n";
		
		for (Athletes a  : athletesList)
		{
			if(a instanceof Jumper)
			{
				report += String.format("%-6s", a.getTableOfAthletes()) + " (Jumper)";				
				report += "\n";			
			}
			if(a instanceof Archer)
			{
				report += String.format("%-6s", a.getTableOfAthletes()) + " (Archer)";
				report += "\n";
			}
			if(a instanceof Swimmer)
			{
				report += String.format("%-6s", a.getTableOfAthletes()) + " (Swimmer)";
				report += "\n";
			}
		}		
		return report;
	}
	
	public String getTableOfArchers()
	{						
		String report = "AN    NAME                  LEVEL		UNIVERSITY               SCORES        Overall\n";
		for (Athletes a  : athletesList)
		{
			if(a instanceof Archer)
			{
				report += String.format("%-6d", a.getCompetitorNumber());
				report += String.format("%-22s", a.getName().getFullName() );
				report += String.format("%-12s", a.getLevel());
				report += String.format("%-30s", ((Archer) a).getUni());			
				report += String.format("%-17s", a.getScoreArray());
				report += String.format ("%.2f", a.getOverallScore());
				report += "\n";
			}
		}
		return report;		
	}
	
	public String getTableOfJumpers()
	{						
		String report = "JN    NAME                  LEVEL		AGE            SCORES           Overall\n";
		for (Athletes a  : athletesList)
		{
			if(a instanceof Jumper)
			{
				report += String.format("%-6d", a.getCompetitorNumber());
				report += String.format("%-22s", a.getName().getFullName() );
				report += String.format("%-20s", a.getLevel());
				report += String.format("%-15d", ((Jumper) a).getJumperAge());			
				report += String.format("%-17s", a.getScoreArray());
				report += String.format ("%.2f", a.getOverallScore());
				report += "\n";
			}
		}
		return report;		
	}
	
	public String getTableOfSwimmers()
	{						
		String report = "SN    NAME                          LEVEL	   COUNTRY              SCORES        Overall\n";
		for (Athletes a  : athletesList)
		{
			if(a instanceof Swimmer)
			{
				report += String.format("%-6d", a.getCompetitorNumber());
				report += String.format("%-30s", a.getName().getFullName() );
				report += String.format("%-15s", a.getLevel());
				report += String.format("%-20s", ((Swimmer) a).getCountry());			
				report += String.format("%-17s", a.getScoreArray());
				report += String.format ("%.2f", a.getOverallScore());
				report += "\n";
			}
		}
		return report;		
	}
		
	public String getReport()
	{		
		String report = "Short details of athletes from 3 different competitions:" + "\n" + "\n";
		
		for (Athletes a  : athletesList)
		{
			if(a instanceof Jumper)
			{
				report += String.format("%-6s", a.getShortDetails()) + " (Jumper)";				
				report += "\n";				
			}
			if(a instanceof Archer)
			{
				report += String.format("%-6s", a.getShortDetails()) + " (Archer)";
				report += "\n";
			}
			if(a instanceof Swimmer)
			{
				report += String.format("%-6s", a.getShortDetails()) + " (Swimmer)";
				report += "\n";
			}
		}		
		return report;
	}	
	
	/**
	 * this method demonstrates searching through the array, 
	 * and stopping by returning when a match is found
	 * @param JN is JumperNumber
	 * @return returns the Staff object with a specified number, 
	 */	
	public String findByJumperNumber(int JN)
    {
    	for (Athletes a : athletesList)
    		if(a instanceof Jumper)
    		{
    			if (a.getCompetitorNumber() == JN)
    			{
    				comNumber = a.getCompetitorNumber() + "";
    				comName = a.getName().getFullName();
    				comLevel = a.getLevel();
    				comAt = ((Jumper) a).getJumperAge() + "";
    				comSc = a.getScoreArray();
    				index = getIndex(a);
    				instance = "Jumper";
    				
    				return ((Jumper) a).getEditDetails();
    			}
    		}
    	return null;
    }
	
	public String findByArcherNumber(int cN)
    {
    	for (Athletes a : athletesList)
    	{
    		if(a instanceof Archer)
    		{
    			if (a.getCompetitorNumber() == cN)
    			{
    				comNumber = a.getCompetitorNumber() + "";
    				comName = a.getName().getFullName();
    				comLevel = a.getLevel();
    				comAt = ((Archer) a).getUni();
    				comSc = a.getScoreArray();
    				index = getIndex(a);
    				instance = "Archer";
    				
    				return ((Archer) a).getEditDetails();
    			}
    		}
    	}    	
    	return null;
    }
	
	public String findBySwimmerNumber(int sN)
    {
    	for (Athletes a : athletesList)
    		if(a instanceof Swimmer)
    		{
    			if (a.getCompetitorNumber() == sN)
    			{
    				comNumber = a.getCompetitorNumber() + "";
    				comName = a.getName().getFullName();
    				comLevel = a.getLevel();
    				comAt = ((Swimmer) a).getCountry();
    				comSc = a.getScoreArray();
    				index = getIndex(a);
    				instance = "Swimmer";
    				
    				return ((Swimmer) a).getEditDetails();
    			}
    		}
    	return null;
    }
    
	public Athletes getByIndex(int n) 
	{
    	return athletesList.get(n);
    }
    
    /**
     * @return the number of items in the list
     */
    public int getSize() 
    {
    	return athletesList.size();
    }
	
        
    /**     
     * this method gets FullDeatails method from Jumper class
     * @return the report of full details
     */
    
    public void add(Archer a) 
	{
		athletesList.add(a);
	}
    
    public void add(Jumper j) 
	{
		athletesList.add(j);
	}    
  
  	public void add(Swimmer s)
  	{
  		athletesList.add(s);
  	}
    
    /**
     * Method to write reports to file
     * @param filename the name of the file to be written to
     * @param report the text to be written to the file
     * @param report1 the text to be written to the file
     */
    public  void writeToFile(String filename, String report, String report1) 
	{	
		 FileWriter fw;
		 try 
		 {
		    fw = new FileWriter(filename);
		    fw.write("The report\n");
		    fw.write("\n");
		    fw.write(report + "\n" + report1);		    
		 	fw.close();
		 }
		 //message and stop if file not found
		 catch (FileNotFoundException fnf)
		 {
			 System.out.println(filename + " not found ");
			 System.exit(0);
		 }
		 //stack trace here because we don't expect to come here
		 catch (IOException ioe)
		 {
		    ioe.printStackTrace();
		    System.exit(1);
		 }
	}   
       
    /**
   	 * this method gets the highest score from athletesList
   	 * @return the highest score
   	 */
    public double getTheHighestScore() 
    {	   	    	
		double highestScore = 0;
		for (Athletes s : athletesList) 
		{
			double hs = s.getOverallScore();
			if (hs> highestScore) 
			{
				highestScore = hs;	
				
			}
		}			
		return highestScore;
	}
    
    public double getArcherMaxOverall()
	{	
		double[] overalls = new double[getSize()];			
		int e = 0;
		for (Athletes a  : athletesList)
		{
			if (a instanceof Archer)
			{
				double over = a.getOverallScore();
				overalls[e] = over;		    
				e++;
			}
		}
		double max = overalls[0];
		for (int i = 0; i<overalls.length; i++)
		{
			if(overalls[i]>max)
            {
                max = overalls[i];
            }
		}
	    return max;		
	}
    
    public String getArcherWithMax()
	{
		String wnr = "";
		for (Athletes a  : athletesList)
		{			
			if(a instanceof Archer)
			{
				if(getArcherMaxOverall() == a.getOverallScore())
				{
					wnr = a.getName().getFullName();
				}		
			}
		}
		return wnr;
	}
    
    /**
     * this method gets the amount of winners   
     * @return returns the amount of winners
     */    
    public int getAmountOfWinners() 
    {	   	    	
    	int k = 0;
		for (Athletes s : athletesList) 
		{
			double hs = s.getOverallScore();
			if (hs == getTheHighestScore()) 
			{				
				k++;				
			}
		}			
		return k;
	}
    
    /**
     * this method searches how many winners with the same highest score    
     * @return returns winners names  
     */
    public String getWinnersNames()
    {
    	String winnerFullName = "";
    	for (Athletes s : athletesList)
    	{
    		if (getTheHighestScore() == s.getOverallScore())
    		{
    			winnerFullName += s.getName().getFullName() + ", ";
    			
    		}
    	}    	
    	return winnerFullName;		
	}  
	
	public String listByName()
    {
    	Collections.sort(athletesList, new AthletesNameComparator());
    	return getTableOfAthletes();
    }
    
    public String listByID()
    {
    	Collections.sort(athletesList);
    	return getTableOfAthletes();
    }
   
    public String ArchersjFrame()
    {
    	Collections.sort(athletesList);
    	return getTableOfArchers();
    }
    
    public String listByArcherName()
    {    	   	    	
    	Collections.sort(athletesList, new AthletesNameComparator());
    	return getTableOfArchers();
    }
    
    public String listByArcherID()
    {
    	Collections.sort(athletesList);    	
    	return getTableOfArchers();
    }
    public String listByArcherScores()
    {
    	Collections.sort(athletesList, new AthletesScoresComparator());   	
    	return getTableOfArchers();
    }

    public String JumpersjFrame()
    {
    	Collections.sort(athletesList);
    	return getTableOfJumpers();
    }
    
    public String listByJumperName()
    {
    	Collections.sort(athletesList, new AthletesNameComparator());
    	return getTableOfJumpers();
    }
    
    public String listByJumperID()
    {
    	Collections.sort(athletesList);
    	return getTableOfJumpers();
    }
    public String listByJumperScores()
    {
    	Collections.sort(athletesList, new AthletesScoresComparator());
    	return getTableOfJumpers();
    }
    
public String SwimmersjFrame()
{
	Collections.sort(athletesList);
	return getTableOfSwimmers();
}

public String listBySwimmerName()
{    	   	    	
	Collections.sort(athletesList, new AthletesNameComparator());
	return getTableOfSwimmers();
}

public String listBySwimmerID()
{
	Collections.sort(athletesList);    	
	return getTableOfSwimmers();
}
public String listBySwimmerScores()
{
	Collections.sort(athletesList, new AthletesScoresComparator());   	
	return getTableOfSwimmers();
}

        
    public int getIndex(Athletes a)
    {
    	return athletesList.indexOf(a);
    }
    
    public int getIndexByCN(int cN)
    {
    	int ind = 0;
    	for (Athletes a  : athletesList)
		{
    		if (a.getCompetitorNumber() == cN)
    		{
    			ind = athletesList.indexOf(a);
    		}
		}
    	return ind;
    }
    
    public void editList(int index, Athletes a)
    {
    	athletesList.set(index, a);
    }
    
    public void deleteAth(int index)
    {
    	athletesList.remove(index);
    }
    
    public String getCompetNumber()
    {
    	return comNumber;
    }
    
	public String getCompetName()
	{
		return comName;
	}
	
	public String getCompetLevel()
	{
		return comLevel;
	}
	
	public String getCompetAttribute()
	{
		return comAt;
	}
	
	public String getCompetScore()
	{
		return comSc;
	}
	
	public int getCompetIndex()
	{
		return index;
	}
	
	public String getInstance()
	{
		return instance;
	}
	
	public void setCompetNumber(String n)
    {
    	comNumber = n;
    }
		
	public Athletes getAtIndex(int index) 
	{
		return athletesList.get(index);
	}
	
	public boolean checkCompetNum(String athlete, int number)
	{
		int[] numbers = new int[athletesList.size()];	
		for (int numbersIndex = 0; numbersIndex < athletesList.size(); numbersIndex++)
		{
			for (Athletes a : athletesList)
		    {
				Athletes ath = getAtIndex(numbersIndex);
				ath.getCompetitorNumber();
				if (athlete.equals("Archer"))
				{
					if(a instanceof Archer)
					{
						if (a.getCompetitorNumber() == ath.getCompetitorNumber())
						{
							numbers[numbersIndex] = a.getCompetitorNumber();						
						}
					}
				}
				if (athlete.equals("Jumper"))
				{
					if(a instanceof Jumper)
					{				
						if (a.getCompetitorNumber() == ath.getCompetitorNumber())
						{
							numbers[numbersIndex] = a.getCompetitorNumber();						
						}
					}
				}
				if (athlete.equals("Swimmer"))
				{
					if(a instanceof Swimmer)
					{				
						if (a.getCompetitorNumber() == ath.getCompetitorNumber())
						{
							numbers[numbersIndex] = a.getCompetitorNumber();						
						}
					}
				}
		    }
			if (number == numbers[numbersIndex])
			{
				return true;
			}
    	}		
		return false;
	}	
}
