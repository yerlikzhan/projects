//import all the GUI classes
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * Simple GUI for StaffList application
 */
public class AthletesListGUI extends JFrame implements ActionListener
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// The staff list to be searched.
    public AthletesList athletesList;
    private String[] cat = { "Archer", "Jumper", "Swimmer"};    
    private String[] levels = { "Sniper", "Archer", "Shooter"};
    private String lvl = "";
    //GUI components
    JTextField result, editCN, editLevel, editAt;
    JTextField searchField, editName, editScores, category;
    JButton search, btJumper, btArcher,btSwimmer, edit, addAth;
    JButton showListById, showListByName, close, del, add, canc;
    JTextArea displayList;
    JScrollPane scrollList;
    JFrame delete; 
    @SuppressWarnings({ "rawtypes", "unchecked" })
	JComboBox catList = new JComboBox(cat);
    @SuppressWarnings({ "rawtypes", "unchecked" })
	JComboBox levelList = new JComboBox(levels);
    JLabel lAth, lLvl, lUAC;  
    
    /**
     * Create the frame with its panels.
     * @param list	The staff list to be searched.
     */    
    public AthletesListGUI(AthletesList list)
    {
        this.athletesList = list;        
        //set up window title
        setTitle("AthletesList");
        exit();
		setupSouthPanel();
		setupNorthPanel();
		setupCenterPanel();
        //pack and set visible
        pack();
        setVisible(true);
        centerFrame(this);        
        result.setText("Result of search will appear here");
        this.setSize(850, 700);        
    } 
    
    @SuppressWarnings("static-access")
	public void exit()
    {    	
    	setDefaultCloseOperation(this.EXIT_ON_CLOSE);
    	athletesList.listByID();
    	recordReport();    	   	
    }
    
    private void setupCenterPanel()
    {
        displayList = new JTextArea();
        displayList.setFont(new Font (Font.MONOSPACED, Font.PLAIN,14));
        displayList.setEditable(false);
        displayList.setText(athletesList.listByID());
        scrollList = new JScrollPane(displayList);
        this.add(scrollList,BorderLayout.CENTER);
    }
    
    private void setupSouthPanel()
    {
        //search panel contains label, text field and button
    	JPanel southPanel = new JPanel();
        JPanel searchPanel = new JPanel();
        JPanel fieldPanel = new JPanel();
        JPanel deletePanel = new JPanel();
        JPanel resultPanel = new JPanel();
        
        searchPanel.setLayout(new GridLayout(1,3));
        fieldPanel.setLayout(new GridLayout(1,2));
        deletePanel.setLayout(new GridLayout(1,3));
        resultPanel.setLayout(new GridLayout(1,1));
        searchPanel.add(new JLabel("Enter Competitor Number"));   
        searchField = new JTextField(5);
        searchPanel.add(searchField);   
        search = new JButton("Search");  
        searchPanel.add(search);    
        //specify action when button is pressed
        search.addActionListener(this) ;
                
        //Set up the area where the results will be displayed.
        result= new JTextField(10);
        result.setEditable(false);
        edit = new JButton("Edit");
        edit.addActionListener(this);
        edit.setEnabled(false);
        del = new JButton("Delete");
        del.addActionListener(this);
        del.setEnabled(false);
        add = new JButton("Add Athlete");
        add.addActionListener(this);
        add.setEnabled(true);
        //set up south panel containing 2 previous areas
              
        southPanel.setLayout(new GridLayout(3,1));
        southPanel.add(searchPanel);
        southPanel.add(resultPanel);
        southPanel.add(fieldPanel);
        
        fieldPanel.add(deletePanel);
        resultPanel.add(result);
        deletePanel.add(edit);
        deletePanel.add(del);
        deletePanel.add(add);
               
        //add south panel to the content pane
        this.add(southPanel, BorderLayout.SOUTH);   	
    }
    
    private void setupNorthPanel()
    {
        //add north panel containing some buttons
        JPanel northPanel = new JPanel();
        showListById = new JButton("Sort By CN");
        showListById.addActionListener(this);
        
        showListByName = new JButton("Sort By First Name");
        showListByName.addActionListener(this);
        
        close = new JButton("Close");
        close.addActionListener(this);
                
        btJumper = new JButton("Jumper");
        btJumper.addActionListener(this);
                
        btSwimmer = new JButton("Swimmer");
        btSwimmer.addActionListener(this);
                
        btArcher = new JButton("Archer");
        btArcher.addActionListener(this);
        
        northPanel.add (showListById);
        northPanel.add(showListByName);
        northPanel.add(btArcher);
        northPanel.add(btJumper);
        northPanel.add(btSwimmer);
        northPanel.add(close);
        
        this.add(northPanel, BorderLayout.NORTH);
    }
    
    //come here when button is clicked
    //find which button and act accordingly
    @SuppressWarnings("unchecked")
	public void actionPerformed(ActionEvent e) 
    {   	
    	if (e.getSource() == search) 
    	{
    		search();       			
    		if (result.getText().equals("competitor not found"))
    		{
    			JOptionPane.showMessageDialog(this, "competitor not found");    	
    			edit.setEnabled(false);
    			del.setEnabled(false);
      		}
    		else if (result.getText().equals("Not entered"))
    		{
    			JOptionPane.showMessageDialog(this, "Not entered");    	
    			edit.setEnabled(false);
    			del.setEnabled(false);
    		}
    		else
    		{
    			edit.setEnabled(true);
    			del.setEnabled(true);
    			add.setEnabled(true);
    		}    		 
    	}
    	else if (e.getSource() == showListById) 
    	{
    		displayList.setText(athletesList.listByID());
    	}
    	else if (e.getSource() == showListByName ) 
    	{
    		displayList.setText(athletesList.listByName());
    	}
    	else if (e.getSource() == close) 
    	{
    		System.exit(0);
    	}  
    	else if (e.getSource() == btArcher)
    	{    		
    		ArchersGUI gui = new ArchersGUI(athletesList);
            gui.setVisible(true);            
    	}
    	else if (e.getSource() == btJumper)
    	{
    		JumpersGUI guii = new JumpersGUI(athletesList);
            guii.setVisible(true);            
    	}
    	else if (e.getSource() == btSwimmer)
    	{
    		SwimmersGUI guii = new SwimmersGUI(athletesList);
            guii.setVisible(true);            
    	}
    	else if (e.getSource() == edit)
    	{
    		search();   
			
    		if (result.getText().equals("competitor not found"))
    		{
    			JOptionPane.showMessageDialog(this, "competitor not found");    	
    		}
    		else if (result.getText().equals("Not entered"))
    		{
    			JOptionPane.showMessageDialog(this, "Not entered");    	
    		}
    		else
    		{
    			EditGUI gui = new EditGUI(athletesList);    			   
    			gui.editCN.setEditable(false);
    			this.setVisible(false);
    		}    		
    	}
    	else if (e.getSource() == del)
    	{
    		search();   
		
    		if (result.getText().equals("competitor not found"))
    		{
    			JOptionPane.showMessageDialog(this, "competitor not found");    	
    		}
    		else if (result.getText().equals("Not entered"))
    		{
    			JOptionPane.showMessageDialog(this, "Not entered");    	
    		}
    		else
    		{
    			delteAthlete();
    			displayList.setText(athletesList.listByID());
    			athletesList.setCompetNumber("");
    			searchField.setText("");
    			result.setText("Result of search will appear here");
    			this.setVisible(false);
    			AthletesListGUI at = new AthletesListGUI(athletesList);
    			at.setVisible(true);
    		}
       	}
    	else if (e.getSource() == add)
    	{
    		newAddJFrame();
    		this.setVisible(false);
    	}
    	else if (e.getSource() == canc)
    	{
    		delete.setVisible(false);
    		AthletesListGUI at = new AthletesListGUI(athletesList);
    		at.setVisible(true);
    	}
    	else if (e.getSource() == addAth)
    	{
    		addNewAthlete();    		
    	}
    	else if (e.getSource() == catList){
    		if (catList.getSelectedIndex() == 0)
    		{
    			levelList.removeAllItems(); 
    			levelList.addItem("Sniper");
    	        levelList.addItem("Archer");
    	        levelList.addItem("Shooter");
    			lLvl.setText("Level for Arhcer");
    			lUAC.setText("University");
    			lvl = levelList.getSelectedItem().toString();
    		}
    		
    		if (catList.getSelectedIndex() == 1)
    		{	
    			levelList.removeAllItems();
    			levelList.addItem("Expert");
    	        levelList.addItem("Middle");
    	        levelList.addItem("Novice");
    	        lLvl.setText("level for Jumper");
    			lUAC.setText("Age");
    			lvl = levelList.getSelectedItem().toString();
    		}
    	
    		if (catList.getSelectedIndex() == 2)
    		{	
    			levelList.removeAllItems();
    			levelList.addItem("Expert");
    			levelList.addItem("Standard");
    			levelList.addItem("Novice");
    			lLvl.setText("Level for Swimmer");
    			lUAC.setText("Country");
    			lvl = levelList.getSelectedItem().toString();
    		}
    	}
    }  
  
    private void search()
    {
    	//get search text and search athletes list
    	//setting result text 
    	String search = searchField.getText().trim();
    	String person = "";   	
    	
    	if (search.length() > 0)
    	{
    		result.setText("competitor not found");
    		int searchString = Integer.parseInt(searchField.getText());
    		person = athletesList.findByJumperNumber(searchString);            
    		if (person != null )
    		{
    			result.setText(person.toString());    			
    		} 
   			person = athletesList.findBySwimmerNumber(searchString);
    		if (person != null )
    		{
    			result.setText(person.toString());    				
    		}
    		person = athletesList.findByArcherNumber(searchString);
    		if (person != null )
    		{
    			result.setText(person.toString());    				
    		}
    	}    		
    	else 
    	{
    		result.setText("Not entered");  
    		edit.setEnabled(false);
			del.setEnabled(false);	
    	}
    }    
    
    public void newAddJFrame()
    {
    	JPanel editPanel = new JPanel();
    	delete = new JFrame();
    	delete.setVisible(true);
    	delete.setSize(450, 220);
    	centerFrame(delete);
    	delete.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    	
    	JPanel buttonPanel = new JPanel();
        editPanel.setLayout(new GridLayout(6,1));
        buttonPanel.setLayout(new GridLayout(1,1));
                        
        addAth = new JButton("Add");
        buttonPanel.add(addAth);
        addAth.addActionListener(this);
        
        canc = new JButton("Cancel");
        buttonPanel.add(canc);
        canc.addActionListener(this);
        
        lAth = new JLabel("Choose the category of Athlete");
        editPanel.add(lAth);       
        
        catList.setSelectedIndex(0);
        catList.addActionListener(this);
        editPanel.add(catList);        
        editPanel.add(new JLabel("Competitor Number"));
             
        editCN = new JTextField(20);
        editPanel.add(editCN);
        
        editPanel.add(new JLabel("Name"));        
        editName = new JTextField(20);    	
        editPanel.add(editName);
        
        lLvl = new JLabel("Level for Archer");        
        editPanel.add(lLvl);
       
        levelList.setSelectedIndex(0);
        levelList.addActionListener(this);
        levelList.setVisible(true);
        editPanel.add(levelList);
               
        editAt = new JTextField(20);
        lUAC = new JLabel("University");
        editPanel.add(lUAC);
        editPanel.add(editAt);
               
        editScores = new JTextField(20);
        editPanel.add(new JLabel("Scores"));
        editPanel.add(editScores);
        
        JPanel southPanel = new JPanel();
        southPanel.setLayout(new GridLayout(1,1));
        southPanel.add(editPanel);
        
        //add south panel to the content pane
        delete.add(southPanel, BorderLayout.NORTH);
        delete.add(buttonPanel, BorderLayout.SOUTH);        
    }
    
    public static void centerFrame(Window frame) 
    {
        frame.setLocationRelativeTo(null);
    }
    
    public void recordReport() 	
    {
		String Report = athletesList.getReport();
		String Report1 =athletesList.getWinnersNames() + athletesList.getTheHighestScore();		
		athletesList.writeToFile("ReportAthletes.txt", Report, Report1);
	}
  	
    public void delteAthlete()
  	{   	
    	int cNum = Integer.parseInt(athletesList.getCompetNumber().trim());
    	int ind = athletesList.getIndexByCN(cNum);
    	athletesList.deleteAth(ind);
  	}
    
    public void addNewAthlete()
  	{
    	try
		{   
    		lvl = levelList.getSelectedItem().toString();
       		int category = catList.getSelectedIndex();
	  		int cNum = Integer.parseInt(editCN.getText());
			Name cName = new Name(editName.getText().trim());			
			String att = editAt.getText();
			String marks [] = editScores.getText().trim().split(" ");
			int scoreLength = marks.length;	
			String sc[] = new String[scoreLength];
			System.arraycopy(marks, 0, sc, 0, scoreLength);
			int scores[] = new int[sc.length];
		    	
			if (category == 0)
			{				
				if (athletesList.checkCompetNum("Archer", cNum) == false)
				{
					if (marks.length == 6)
					{    		
						//converting string[] into int[]
						for(int i = 0; i < scores.length; i++)
						{			   
							if (Integer.parseInt(sc[i]) > 0 && Integer.parseInt(sc[i]) < 6)
							{
								scores[i] = Integer.parseInt(sc[i]); 
							}
							else
							{
								scores[0] =  0;
							}    			
						}
						if (scores[0] > 0)
						{							
							Archer a = new Archer(cNum, cName, lvl, att, scores);
							athletesList.add(a);
							delete.setVisible(false);    	    		
							AthletesListGUI at = new AthletesListGUI(athletesList);
							at.setVisible(true);
						}
						else
						{
							JOptionPane.showMessageDialog(this, "Scores must be between 1 and 5 inclusive");
						}
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Please provide 6 scores separated by space");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(this, "Competitor number is in the list of Archers, "
							+ "please change the competitor number");
				}
			}
			
			else if (category == 1)			
			{
				if (athletesList.checkCompetNum("Jumper", cNum) == false)
				{
					if (marks.length == 5)
        			{    		
        				//converting string[] into int[]
        				for(int i = 0; i < scores.length; i++)
        				{			   
        					if (Integer.parseInt(sc[i]) > 0 && Integer.parseInt(sc[i]) < 6)
        					{
        						scores[i] = Integer.parseInt(sc[i]); 
        					}
        					else
        					{
        						scores[0] =  0;
        					}    			
        				}
        				if (scores[0] > 0)
        				{
        					int age = Integer.parseInt(att);
        					Jumper j = new Jumper(cNum, cName, age, lvl, scores);
        					athletesList.add(j);
        					delete.setVisible(false);    	    		
							AthletesListGUI at = new AthletesListGUI(athletesList);
							at.setVisible(true);
        				}
        				else
        				{
        					JOptionPane.showMessageDialog(this, "Scores must be between 1 and 5 inclusive");
        				}
        			}
        			else
        			{
        				JOptionPane.showMessageDialog(this, "Please provide 5 scores separated by space");
        			}
				}
				else
				{
					JOptionPane.showMessageDialog(this, "Competitor number is in the list of Jumpers, "
							+ "please change the competitor number");
				}
			}
			
			else if (category == 2)
			{
				if (athletesList.checkCompetNum("Swimmer", cNum) == false)
				{
					if (marks.length == 5)
        			{    		
        				//converting string[] into int[]
        				for(int i = 0; i < scores.length; i++)
        				{			   
        					if (Integer.parseInt(sc[i]) > 0 && Integer.parseInt(sc[i]) < 6)
        					{
        						scores[i] = Integer.parseInt(sc[i]); 
        					}
        					else
        					{
        						scores[0] =  0;
        					}    			
        				}
        				if (scores[0] > 0)
        				{    					
        					Swimmer s = new Swimmer(cNum, cName, lvl, att, scores);
        					athletesList.add(s);
        					delete.setVisible(false);    	    		
							AthletesListGUI at = new AthletesListGUI(athletesList);
							at.setVisible(true);
        				}
        				else
        				{
        					JOptionPane.showMessageDialog(this, "Scores must be between 1 and 5 inclusive");
        				}
        			}
					else
        			{
        				JOptionPane.showMessageDialog(this, "Please provide 5 scores separated by space");
        			}
					
				}
				else
				{
					JOptionPane.showMessageDialog(this, "Competitor number is in the list of Swimmers, "
							+ "please change the competitor number");
				}
			}
			else
			{
				JOptionPane.showMessageDialog(this, "Please, state correct category: Archer / Jumper / Swimmer");
			}
		}
		catch (NumberFormatException ex)
		{
			JOptionPane.showMessageDialog(this, "Incorrect data, please provide correct competitor number"
					+ " and scores divided by space");
		}
		catch (StringIndexOutOfBoundsException n)
		{
			JOptionPane.showMessageDialog(this, "Incorrect data");
		}	
	}    
}
