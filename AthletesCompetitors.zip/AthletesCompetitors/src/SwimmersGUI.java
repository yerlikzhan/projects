//import all the GUI classes
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class SwimmersGUI extends JFrame implements ActionListener
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// The staff list to be searched.
    private AthletesList athletesList;       
    JTextField result;
    JTextField searchField;
    JButton search;
    JScrollPane scrollList;
    JButton showListById, showListByName, swowListByScores, close;
    JTextArea displayList;   
    
    /**
     * Create the frame with its panels.
     * @param list	The staff list to be searched.
     */   
    public SwimmersGUI(AthletesList list)
    {
        this.athletesList = list;        
        //set up window title
        setTitle("Swimmers");     
		setupNorthPanel();
		setupCenterPanel();
        //pack and set visible
        pack();
        setVisible(true);     
    } 
    
    
    private void setupCenterPanel()
    {
        displayList = new JTextArea(20,100);
        displayList.setFont(new Font (Font.MONOSPACED, Font.PLAIN,14));
        displayList.setEditable(false);
        displayList.setText(athletesList.SwimmersjFrame());
        scrollList = new JScrollPane(displayList);
        this.add(scrollList,BorderLayout.CENTER);
    }    
    
    private void setupNorthPanel()
    {
        //add north panel containing some buttons
        JPanel northPanel = new JPanel();
        showListById = new JButton("Sort By SN");
        showListById.addActionListener(this);
        
        showListByName = new JButton("Sort By First Name");
        showListByName.addActionListener(this);
        
        swowListByScores = new JButton("Sort By Scores");
        swowListByScores.addActionListener(this);
        
        close = new JButton("Close");
        close.addActionListener(this);
        
        northPanel.add (showListById);
        northPanel.add(showListByName);
        northPanel.add (swowListByScores);
        northPanel.add(close);
        this.add(northPanel, BorderLayout.NORTH);
    }
    
    //come here when button is clicked
    //find which button and act accordingly
    public void actionPerformed(ActionEvent e) 
    { 
    	if (e.getSource() == showListById) 
    	{
    		displayList.setText(athletesList.listBySwimmerID());
    	}
    	else if (e.getSource() == showListByName ) 
    	{
    		displayList.setText(athletesList.listBySwimmerName());
    	}
    	else if (e.getSource() == swowListByScores) 
    	{    		    		
    		displayList.setText(athletesList.listBySwimmerScores());
    	}
    	else if (e.getSource() == close) 
    	{    		    		
            setVisible(false);
    	}   	
    }
}
