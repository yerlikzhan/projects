//F21SF - Yerlikzhan Athl 
public class Archer extends Athletes
{
	
	private String university;	
		
	//constructor to create archer object with candidate number, name, level, university and score
	public Archer(int cNumber, Name cName, String lvl, String uni, int[] scores)
	{
		super(cNumber, cName, lvl, scores);	
		this.university = uni;
	}	
	
	//method to return university of the archer
	public String getUni()
	{
		return university;
	}
	
	/*each archer has level, there are 3 types of levels, depending on the level
	 *archer has coefficient which is affects on his overall score 
	 */ 
	public double getCoeff()
	{
		String lvl = getLevel();
		double coeff = 0;
	    switch(lvl)
	    {	
	       case ("Sniper") :
	       {
	           coeff = 0.94; 
	           break;
	       }
	       case ("Archer") :
	       {
	           coeff = 0.97;
	           break;
	       }
	       case ("Shooter") :
	       {
	           coeff = 1;
	       }
	    }
	    return coeff;
	}
	
	//returns the overall score
	public double getOverallScore()
	{	
		int total = 0;		
		for (int scoresIndex = 0; scoresIndex < scores.length; scoresIndex++)
		{
			total += scores[scoresIndex];		
		}		
		return (double) total/scores.length * getCoeff();
	}	
	
	//returns max score 
	public int getMaxScore()
	{
		int max = 0;        
        for(int i = 0; i<scores.length; i++)
        {
            if(max<scores[i])
            {
                max = scores[i];
            }
        }
        return max;
	}	
		
	//returns the full details
	public String getFullDetails()
	{
		return "Full details for " + competitorNumber + ":" + "\n" + getName().getFullName() + " (" + level + ")" +
				" with the competitor number: " + competitorNumber + "," + " form the " + university + "\n" + "received these scores: " 
				+ getScoreArray()	+ " which are give " + String.format ("%.2f", getOverallScore()) + " in overall" + ".";
	}
	
	public String getEditDetails()
	{
		String report = "";
		report += "Archer number: " + getCompetitorNumber();
		report += ", full name is " + getName().getFullName();
		report += ", level is " + '"' + getLevel() + '"';
		report += ", from " + getUni();			
		report += ", given scores: " + getScoreArray();
		report += "and overall score: " + String.format ("%.2f", getOverallScore());
				
		return report;
	}
}
