import java.util.Comparator;

public class AthletesScoresComparator implements Comparator<Athletes>
{
	public int compare(Athletes a1, Athletes a2) 
	{
		return ((Double) a2.getOverallScore()).compareTo(a1.getOverallScore());
	}	
}
