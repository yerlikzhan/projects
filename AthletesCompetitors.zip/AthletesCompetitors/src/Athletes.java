
abstract public class Athletes implements Comparable<Athletes>
{
	public int competitorNumber;
    public Name competitorName;
    public String level;
    public int[] scores;

    public Athletes (int cNumber, Name cName, String lvl, int[] scores)
    {
    	//id and name MUSt be provided
        if( cName==null || cNumber == 0)    
        {
          throw new IllegalStateException(
             "Cannot have blank id or name");
        }
    	
    	this.competitorNumber = cNumber;
    	this.competitorName = cName;   
    	this.level = lvl;  
    	this.scores = scores;
    }
    
    //returns Jumper number	
  	public int getCompetitorNumber() {  return competitorNumber;  }	
  	
  	//returns Jumper name	 	
  	public Name getName() {  return competitorName;  }	
  	
    //this method returns scores	
  	public String getScoreArray()
	{
		String k = "";
		for (int i=0; i<scores.length; i++)
		{			
			k+= scores[i] + " ";		
		}
		return k;
	}
  	
  	public String getScoreArrayWithComma()
	{
		String k = "";
		for (int i=0; i<scores.length; i++)
		{	
			k+= scores[i] + ",";	
		}
		return k;
	}
  	
  	//returns Athletes level	
  	public String getLevel() {  return level;  }
  	
    public String toString() 
    {
    	return competitorName.getFullName() + ",  " + level + ",  ";
    }
    
    //this method returns the average score of the first three scores
    public abstract double getOverallScore();
    
    //this method returns full details about a chosen athlete
    public abstract String getFullDetails(); 
    
    public abstract String getEditDetails();
    
    //this method returns short details about a chosen jumper
    public String getShortDetails()
    {
    	String report = "";
    	report += String.format("%-4s", "CN");
    	report += String.format("%-6d", competitorNumber);
    	report += String.format("%-7s", "(" + competitorName.getCapitalLetters() + ")");
    	report += String.format("%-7s","has overall score ");
    	report += String.format("%.2f", getOverallScore());    	
		return report;
	}
    
    public String getTableOfAthletes()
    {
    	String report = "";
    	report += String.format("%-4s", "CN");
    	report += String.format("%-6d", competitorNumber);
    	report += String.format("%-27s",competitorName.getFullName());
    	report += String.format("%-15s",getScoreArray());
    	report += String.format("%-7s","has overall score ");
    	report += String.format("%.2f", getOverallScore());    	
		return report;    	
    }
    
    public boolean equals(Object obj)
    {
        if(obj instanceof Athletes)
        {
        	Athletes otherStaff = (Athletes) obj;
            return competitorNumber == otherStaff.getCompetitorNumber();
        }
        else
        {
            return false;
        }
    }
    
    public void setCompetitorNumber(int competitorNumber) 
    {
    	this.competitorNumber = competitorNumber; 
    }
    
    public int compareTo(Athletes otherDetails)
    {
        return ((Integer) competitorNumber).compareTo(otherDetails.getCompetitorNumber());
    }   
}